"""Persistence for discovered MCP tool manifests."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from fusion_mcp_adapter.tool_result import ToolManifest


class ManifestStore:
    """Read and write Fusion MCP manifests."""

    def __init__(self, root: Path | str = "manifests") -> None:
        self.root = Path(root)

    def save(self, manifest: ToolManifest) -> Path:
        """Save timestamped and source-specific latest manifest files."""

        self.root.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        source = self._source_key(manifest.source)
        path = self.root / f"fusion_mcp_tools_{source}_{timestamp}.json"
        latest = self.root / f"fusion_mcp_tools_latest_{source}.json"
        text = manifest.model_dump_json(indent=2)
        path.write_text(text, encoding="utf-8")
        latest.write_text(text, encoding="utf-8")
        if source == "real":
            # Backward compatibility for older callers, while mock discovery no
            # longer clobbers the latest real manifest.
            (self.root / "fusion_mcp_tools_latest.json").write_text(text, encoding="utf-8")
        return path

    def load_latest(self, source: str | None = None) -> ToolManifest | None:
        """Load the latest manifest if present.

        When source is omitted, prefer real latest, then legacy latest, then mock.
        This preserves previous behavior for real sessions while keeping mock
        discovery from masking a real endpoint manifest.
        """

        candidates = []
        if source:
            candidates.append(self.root / f"fusion_mcp_tools_latest_{self._source_key(source)}.json")
        else:
            candidates.extend(
                [
                    self.root / "fusion_mcp_tools_latest_real.json",
                    self.root / "fusion_mcp_tools_latest.json",
                    self.root / "fusion_mcp_tools_latest_mock.json",
                ]
            )
        for latest in candidates:
            if latest.exists():
                return ToolManifest.model_validate(json.loads(latest.read_text(encoding="utf-8")))
        return None

    def latest_status(self) -> dict[str, dict[str, str | bool | int]]:
        """Return manifest presence diagnostics for doctor/session health."""

        status: dict[str, dict[str, str | bool | int]] = {}
        for source, filename in {
            "real": "fusion_mcp_tools_latest_real.json",
            "mock": "fusion_mcp_tools_latest_mock.json",
            "legacy": "fusion_mcp_tools_latest.json",
        }.items():
            path = self.root / filename
            status[source] = {
                "path": str(path),
                "exists": path.exists(),
                "bytes": path.stat().st_size if path.exists() else 0,
            }
        return status

    @staticmethod
    def _source_key(source: str | None) -> str:
        value = (source or "real").lower()
        if "mock" in value:
            return "mock"
        if "real" in value or "fusion" in value:
            return "real"
        return value.replace(" ", "_").replace("-", "_")
