"""Persistence for discovered MCP tool manifests."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from fusion_mcp_adapter.tool_result import ToolManifest


class ManifestStore:
    """Read and write Fusion MCP manifests."""

    def __init__(self, root: Path | str = "manifests") -> None:
        self.root = Path(root)

    def save(self, manifest: ToolManifest) -> Path:
        """Save timestamped and latest manifest files."""

        self.root.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        path = self.root / f"fusion_mcp_tools_{timestamp}.json"
        latest = self.root / "fusion_mcp_tools_latest.json"
        latest_source = self.root / f"fusion_mcp_tools_latest_{_safe_source(manifest.source)}.json"
        text = manifest.model_dump_json(indent=2)
        path.write_text(text, encoding="utf-8")
        latest.write_text(text, encoding="utf-8")
        latest_source.write_text(text, encoding="utf-8")
        return path

    def load_latest(self, source: str | None = None) -> ToolManifest | None:
        """Load the latest manifest if present."""

        if source:
            source_latest = self.root / f"fusion_mcp_tools_latest_{_safe_source(source)}.json"
            if source_latest.exists():
                return ToolManifest.model_validate(json.loads(source_latest.read_text(encoding="utf-8")))
            for path in sorted(self.root.glob("fusion_mcp_tools_*.json"), key=lambda item: item.stat().st_mtime, reverse=True):
                if path.name.startswith("fusion_mcp_tools_latest"):
                    continue
                manifest = ToolManifest.model_validate(json.loads(path.read_text(encoding="utf-8")))
                if manifest.source == source:
                    return manifest
            return None

        latest = self.root / "fusion_mcp_tools_latest.json"
        if not latest.exists():
            return None
        return ToolManifest.model_validate(json.loads(latest.read_text(encoding="utf-8")))


def _safe_source(source: str) -> str:
    return "".join(char if char.isalnum() or char in {"_", "-"} else "_" for char in source)
