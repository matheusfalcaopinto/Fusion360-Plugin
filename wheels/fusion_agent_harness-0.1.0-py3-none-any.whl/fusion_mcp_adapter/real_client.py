"""Configurable real Fusion MCP client."""

from __future__ import annotations

import asyncio
import ast
import json
import os
import shlex
import subprocess
import urllib.request
from json import JSONDecodeError
from typing import Any

from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamablehttp_client

from fusion_mcp_adapter.errors import RealMcpNotConfigured
from fusion_mcp_adapter.tool_result import ToolDefinition, ToolManifest, ToolResult


DEFAULT_LOCAL_ENDPOINTS = (
    "http://127.0.0.1:17182/mcp",
    "http://127.0.0.1:17183/mcp",
    "http://127.0.0.1:27182/mcp",
)


class RealMcpClient:
    """Minimal JSON-RPC client for a local Fusion MCP endpoint or command.

    The exact Autodesk Fusion MCP transport is calibrated at runtime. This client
    supports an HTTP endpoint via FUSION_MCP_ENDPOINT and a one-shot command via
    FUSION_MCP_COMMAND. If neither is configured, it probes known local Fusion
    MCP ports, but it never assumes native tool names.
    """

    def __init__(self, endpoint: str | None = None, command: str | None = None, timeout_seconds: float = 120.0) -> None:
        self.endpoint = endpoint or os.getenv("FUSION_MCP_ENDPOINT")
        self.command = command or os.getenv("FUSION_MCP_COMMAND")
        if not self.endpoint and not self.command:
            self.endpoint = _discover_local_endpoint()
        self.timeout_seconds = timeout_seconds

    async def list_tools(self) -> ToolManifest:
        """Discover native MCP tools through tools/list."""

        payload = await self._jsonrpc_with_retry("tools/list", {})
        if not isinstance(payload, dict):
            raise RuntimeError(f"invalid response type: {type(payload).__name__}")
        if "error" in payload:
            raise RuntimeError(payload["error"])
        tool_payload = payload.get("result", payload)
        if not isinstance(tool_payload, dict):
            raise RuntimeError(f"invalid tool payload type: {type(tool_payload).__name__}")
        if "error" in tool_payload:
            raise RuntimeError(tool_payload["error"])
        tools = tool_payload.get("tools", payload.get("tools", []))
        return ToolManifest(
            source="fusion_real",
            tools=[
                ToolDefinition(
                    name=tool.get("name", ""),
                    description=tool.get("description", ""),
                    input_schema=tool.get("inputSchema") or tool.get("input_schema"),
                    output_schema=tool.get("outputSchema") or tool.get("output_schema"),
                )
                for tool in tools
                if tool.get("name")
            ],
        )

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        """Call a real native MCP tool by name."""

        payload = await self._jsonrpc_with_retry("tools/call", {"name": name, "arguments": arguments})
        if not isinstance(payload, dict):
            return ToolResult.failure("MCP_PROTOCOL_ERROR", f"invalid response type: {type(payload).__name__}")
        if "error" in payload:
            return ToolResult.failure("MCP_PROTOCOL_ERROR", str(payload["error"]))
        result = payload.get("result", payload)
        if not isinstance(result, dict):
            return ToolResult.failure("MCP_PROTOCOL_ERROR", f"invalid tool result type: {type(result).__name__}")
        if "error" in result:
            return ToolResult.failure("MCP_PROTOCOL_ERROR", str(result["error"]))
        if result.get("isError") is True:
            return ToolResult.failure("FUSION_OPERATION_FAILED", _content_text(result) or str(result))
        return ToolResult.success(**_normalize_tool_result_data(result))

    async def _jsonrpc(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        if self.endpoint:
            return await self._streamable_http_jsonrpc(method, params)
        if self.command:
            return await asyncio.to_thread(self._command_jsonrpc, method, params)
        raise RealMcpNotConfigured()

    async def _streamable_http_jsonrpc(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Call an MCP streamable HTTP endpoint and return JSON-RPC-shaped data."""

        if not self.endpoint:
            return {"error": "No FUSION_MCP_ENDPOINT configured"}
        async with streamablehttp_client(
            self.endpoint,
            timeout=self.timeout_seconds,
            sse_read_timeout=self.timeout_seconds,
        ) as (read_stream, write_stream, _get_session_id):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()
                if method == "tools/list":
                    result = await session.list_tools()
                    return {
                        "result": {
                            "tools": [
                                tool.model_dump(by_alias=True, mode="json", exclude_none=True)
                                for tool in result.tools
                            ]
                        }
                    }
                if method == "tools/call":
                    name = params.get("name")
                    arguments = params.get("arguments") or {}
                    if not isinstance(name, str) or not isinstance(arguments, dict):
                        return {"error": "tools/call requires string name and object arguments"}
                    result = await session.call_tool(name, arguments)
                    return {"result": result.model_dump(by_alias=True, mode="json", exclude_none=True)}
        return {"error": f"unsupported MCP method: {method}"}

    async def _jsonrpc_with_retry(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        last_error: str | None = None
        for attempt in range(2):
            try:
                return await self._jsonrpc(method, params)
            except Exception as exc:  # pragma: no cover - transport behavior covered in unit tests
                last_error = _format_exception(exc)
                if attempt >= 1:
                    return {"error": last_error}
                await asyncio.sleep(0.1 * (attempt + 1))
        return {"error": last_error or "unknown_transport_error"}

    def _http_jsonrpc(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        request_data = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode("utf-8")
        request = urllib.request.Request(
            self.endpoint or "",
            data=request_data,
            headers={"Content-Type": "application/json", "Accept": "application/json, text/event-stream"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:  # noqa: S310 - local endpoint
            return _load_json(response.read().decode("utf-8"))

    def _command_jsonrpc(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        request_data = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        command = self.command
        if not command:
            return {"error": "No FUSION_MCP_COMMAND configured"}
        command_parts = shlex.split(command)
        completed = subprocess.run(
            command_parts,
            input=request_data,
            text=True,
            capture_output=True,
            timeout=self.timeout_seconds,
            check=False,
        )
        if completed.returncode != 0:
            return {"error": completed.stderr.strip() or f"command exited {completed.returncode}"}
        return _load_json(completed.stdout)


def _load_json(value: str) -> dict[str, Any]:
    value = _sse_data_payload(value) or value
    try:
        payload = json.loads(value)
    except JSONDecodeError as exc:
        return {"error": f"invalid json response: {exc}"}
    if not isinstance(payload, dict):
        return {"error": f"unexpected payload type: {type(payload).__name__}"}
    return payload


def _discover_local_endpoint(timeout_seconds: float = 0.35) -> str | None:
    for endpoint in DEFAULT_LOCAL_ENDPOINTS:
        health_uri = endpoint.removesuffix("/mcp") + "/health"
        try:
            with urllib.request.urlopen(health_uri, timeout=timeout_seconds) as response:  # noqa: S310 - local MCP probe
                if 200 <= int(getattr(response, "status", 200)) < 500:
                    return endpoint
        except Exception:
            continue
    return None


def _format_exception(exc: BaseException) -> str:
    nested = getattr(exc, "exceptions", None)
    if nested:
        details = "; ".join(_format_exception(child) for child in nested)
        return f"{type(exc).__name__}: {details}"
    return f"{type(exc).__name__}: {exc}"


def _sse_data_payload(value: str) -> str | None:
    """Extract the last JSON-looking data payload from an SSE response."""

    data_payloads: list[str] = []
    current: list[str] = []
    for line in value.splitlines():
        if not line.strip():
            if current:
                data_payloads.append("\n".join(current))
                current = []
            continue
        if line.startswith("data:"):
            current.append(line.partition(":")[2].lstrip())
    if current:
        data_payloads.append("\n".join(current))
    for payload in reversed(data_payloads):
        candidate = payload.strip()
        if candidate.startswith("{") and candidate.endswith("}"):
            return candidate
    return None


def _normalize_tool_result_data(result: dict[str, Any]) -> dict[str, Any]:
    structured = result.get("structuredContent") or result.get("structured_content")
    if isinstance(structured, dict):
        return structured

    parsed_text = _parse_content_text(_content_text(result))
    if parsed_text:
        return parsed_text

    return result


def _content_text(result: dict[str, Any]) -> str:
    content = result.get("content")
    if not isinstance(content, list):
        return ""
    texts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text" and isinstance(block.get("text"), str):
            texts.append(block["text"])
    return "\n".join(texts)


def _parse_content_text(text: str) -> dict[str, Any]:
    if not text:
        return {}
    try:
        loaded = json.loads(text.strip())
    except JSONDecodeError:
        loaded = None
    if isinstance(loaded, dict):
        return loaded
    data: dict[str, Any] = {"text": text}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("**") or line == "deltas:":
            continue
        key, separator, value = line.partition(":")
        if not separator:
            continue
        key = key.strip()
        if not key or " " in key:
            continue
        data[key] = _parse_scalar(value.strip())
    return data


def _parse_scalar(value: str) -> Any:
    if value == "":
        return ""
    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    try:
        return ast.literal_eval(value)
    except (SyntaxError, ValueError):
        pass
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        return value
