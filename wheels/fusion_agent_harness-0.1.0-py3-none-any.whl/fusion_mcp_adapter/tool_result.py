"""Shared adapter result models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ToolDefinition(BaseModel):
    """A native MCP tool definition after discovery."""

    name: str
    description: str = ""
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None


class ToolManifest(BaseModel):
    """Collection of discovered native MCP tools."""

    source: str = "unknown"
    tools: list[ToolDefinition] = Field(default_factory=list)

    def names(self) -> set[str]:
        """Return all native tool names in the manifest."""

        return {tool.name for tool in self.tools}


class ToolResult(BaseModel):
    """Normalized native tool result."""

    ok: bool
    data: dict[str, Any] = Field(default_factory=dict)
    error_code: str | None = None
    error_message: str | None = None

    @classmethod
    def success(cls, **data: Any) -> "ToolResult":
        """Build a successful result."""

        return cls(ok=True, data=data)

    @classmethod
    def failure(cls, error_code: str, error_message: str) -> "ToolResult":
        """Build a failed result."""

        return cls(ok=False, error_code=error_code, error_message=error_message)

