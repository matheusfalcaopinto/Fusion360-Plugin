"""OpenCode-facing MCP wrapper for the Fusion agent harness."""

