"""Local MCP server that exposes the safe Fusion agent harness to OpenCode."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable

import anyio
import mcp.types as types
from mcp.server.lowlevel import Server

from agent_core.planner import PlanningRequest, RuleBasedPlanner
from agent_core.session_controller import SessionController, SessionOptions
from benchmark.loader import load_benchmark_cases
from benchmark.runner import BenchmarkRunner
from cad_spec.models import CadSpec
from cli.main import _doctor, _tools_probe, _tools_propose_mapping
from memory.gate import MemoryGate
from memory.retriever import MemoryRetriever
from memory.store import MemoryStore
from skills.loader import SkillLoader
from skills.router import SkillRouter


JsonDict = dict[str, Any]
Handler = Callable[[JsonDict], Awaitable[JsonDict]]

WORKSPACE_ROOT = Path("workspace")
OUTPUTS_ROOT = Path("outputs")
MANIFEST_ROOT = Path("manifests")
BENCHMARK_ROOT = Path("benchmarks")
SESSION_ARTIFACTS = {
    "cad_spec.json",
    "prompt.md",
    "verification.json",
    "tool_trace.jsonl",
    "session_journal.json",
    "final_summary.md",
    "memory_summary.md",
    "capture.json",
}


@dataclass(frozen=True)
class ToolSpec:
    """MCP tool metadata and handler."""

    name: str
    description: str
    input_schema: JsonDict
    handler: Handler


def list_tool_definitions() -> list[types.Tool]:
    """Return MCP tool definitions for the safe harness wrapper."""

    return [
        types.Tool(name=spec.name, description=spec.description, inputSchema=spec.input_schema)
        for spec in tool_specs()
    ]


async def execute_tool(name: str, arguments: JsonDict | None = None) -> JsonDict:
    """Execute one wrapper tool by name and return a JSON-serializable payload."""

    spec = _tool_spec_map().get(name)
    if spec is None:
        raise ValueError(f"unknown fusion agent MCP tool: {name}")
    return await spec.handler(arguments or {})


def build_server() -> Server:
    """Build the stdio MCP server used by OpenCode."""

    app = Server("fusion-agent-harness")

    @app.list_tools()
    async def list_tools() -> list[types.Tool]:
        return list_tool_definitions()

    @app.call_tool()
    async def call_tool(name: str, arguments: dict | None) -> list[types.ContentBlock] | types.CallToolResult:
        try:
            payload = await execute_tool(name, dict(arguments or {}))
        except Exception as exc:  # noqa: BLE001 - MCP boundary normalizes all failures
            return types.CallToolResult(
                content=[
                    types.TextContent(
                        type="text",
                        text=_json_text({"ok": False, "error": f"{type(exc).__name__}: {exc}"}),
                    )
                ],
                isError=True,
            )
        return [types.TextContent(type="text", text=_json_text({"ok": True, "result": payload}))]

    return app


def main() -> int:
    """Run the MCP server over stdio."""

    from mcp.server.stdio import stdio_server

    async def arun() -> None:
        app = build_server()
        async with stdio_server() as streams:
            await app.run(streams[0], streams[1], app.create_initialization_options())

    anyio.run(arun)
    return 0


def tool_specs() -> list[ToolSpec]:
    """Return all safe MCP wrapper tool specs."""

    return [
        ToolSpec("fusion_agent_doctor", "Show harness configuration and paths.", _schema(), _doctor_tool),
        ToolSpec("fusion_agent_probe", "Probe candidate real Fusion MCP endpoints.", _schema({"endpoint": _string()}), _probe_tool),
        ToolSpec("fusion_agent_inspect", "Inspect current design state through mock or real facade.", _mode_schema(), _inspect_tool),
        ToolSpec("fusion_agent_verify_active_design", "Verify the active design against a planned CadSpec without executing geometry.", _verify_schema(), _verify_active_design_tool),
        ToolSpec("fusion_agent_capture_viewport", "Capture the active Fusion viewport through the safe facade.", _capture_schema(), _capture_viewport_tool),
        ToolSpec("fusion_agent_run_session", "Run one full modeling session through the harness.", _run_schema(), _run_session_tool),
        ToolSpec("fusion_agent_dry_run_session", "Plan and simulate one modeling session without MCP calls.", _dry_run_schema(), _dry_run_session_tool),
        ToolSpec("fusion_agent_list_sessions", "List saved session journals.", _schema({"project": _string(), "limit": _integer(1, 100)}), _list_sessions_tool),
        ToolSpec("fusion_agent_read_session_artifact", "Read an allowlisted session artifact.", _read_artifact_schema(), _read_session_artifact_tool),
        ToolSpec("fusion_agent_read_trace", "Read parsed events from a session tool trace.", _read_trace_schema(), _read_trace_tool),
        ToolSpec("fusion_agent_plan_spec", "Create a CAD Spec JSON document for a prompt.", _plan_schema(), _plan_spec_tool),
        ToolSpec("fusion_agent_validate_spec", "Validate a CAD Spec JSON string.", _schema({"spec_json": _string()}, ["spec_json"]), _validate_spec_tool),
        ToolSpec("fusion_agent_export_spec_json", "Plan a CAD Spec and optionally save it under outputs/.", _export_spec_schema(), _export_spec_json_tool),
        ToolSpec("fusion_agent_list_benchmarks", "List benchmark suites and case counts.", _schema(), _list_benchmarks_tool),
        ToolSpec("fusion_agent_run_benchmark", "Run a benchmark suite through the harness.", _benchmark_schema(), _run_benchmark_tool),
        ToolSpec("fusion_agent_read_benchmark_report", "Read a benchmark report JSON file.", _schema({"path": _string()}), _read_benchmark_report_tool),
        ToolSpec("fusion_agent_discover_tools", "Discover MCP tools through mock or real client and save manifest.", _mode_schema(default="real"), _discover_tools_tool),
        ToolSpec("fusion_agent_propose_mapping", "Propose safe facade/native mappings from latest manifest.", _schema(), _propose_mapping_tool),
        ToolSpec("fusion_agent_read_manifest", "Read the latest or named tool manifest.", _schema({"path": _string()}), _read_manifest_tool),
        ToolSpec("fusion_agent_memory_search", "Search gated global/project memory.", _memory_search_schema(), _memory_search_tool),
        ToolSpec("fusion_agent_memory_write", "Write project Markdown memory.", _memory_write_schema(), _memory_write_tool),
        ToolSpec("fusion_agent_memory_list_project", "List global and project memory records.", _schema({"project": _string()}), _memory_list_project_tool),
        ToolSpec("fusion_agent_skills_list", "List all filesystem-backed harness skills.", _schema(), _skills_list_tool),
        ToolSpec("fusion_agent_skills_get", "Read one harness skill by name.", _schema({"name": _string()}, ["name"]), _skills_get_tool),
        ToolSpec("fusion_agent_skills_rank", "Rank harness skills for a request.", _schema({"query": _string(), "limit": _integer(1, 12)}, ["query"]), _skills_rank_tool),
    ]


async def _doctor_tool(_: JsonDict) -> JsonDict:
    return _doctor()


async def _probe_tool(args: JsonDict) -> JsonDict:
    return await _tools_probe(_optional_str(args, "endpoint"))


async def _inspect_tool(args: JsonDict) -> JsonDict:
    mode = _mode(args, default="mock")
    return await SessionController().inspect(mode=mode, options=_session_options(mode=mode))


async def _verify_active_design_tool(args: JsonDict) -> JsonDict:
    prompt = _required_str(args, "prompt")
    project = _optional_str(args, "project") or "opencode"
    _safe_name(project, "project")
    mode = _mode(args, default="mock")
    result = await SessionController().verify_active(
        prompt,
        project=project,
        mode=mode,
        options=_session_options(mode=mode, project=project),
    )
    return result.model_dump(mode="json")


async def _capture_viewport_tool(args: JsonDict) -> JsonDict:
    project = _optional_str(args, "project") or "opencode"
    _safe_name(project, "project")
    mode = _mode(args, default="mock")
    output_dir_arg = _optional_str(args, "output_dir") or ""
    output_dir = _safe_relative_path(OUTPUTS_ROOT, output_dir_arg) if output_dir_arg else OUTPUTS_ROOT
    name = _optional_str(args, "name") or "active_design_capture"
    if Path(name).is_absolute() or ".." in Path(name).parts or "/" in name or "\\" in name:
        raise ValueError("name must be a simple relative PNG filename")
    view = _optional_str(args, "view") or "isometric"
    if view not in {"isometric", "front", "top", "right"}:
        raise ValueError("view must be one of: isometric, front, top, right")
    result = await SessionController().capture_viewport(
        project=project,
        mode=mode,
        options=_session_options(mode=mode, project=project),
        output_dir=output_dir,
        name=name,
        view=view,
        isolate_prefix=_optional_str(args, "isolate_prefix"),
        width=int(args.get("width", 1600)),
        height=int(args.get("height", 1100)),
    )
    return result.model_dump(mode="json")


async def _run_session_tool(args: JsonDict) -> JsonDict:
    return await _run_session(args, dry_run=bool(args.get("dry_run", False)))


async def _dry_run_session_tool(args: JsonDict) -> JsonDict:
    return await _run_session(args, dry_run=True)


async def _run_session(args: JsonDict, *, dry_run: bool) -> JsonDict:
    prompt = _required_str(args, "prompt")
    project = _optional_str(args, "project") or "opencode"
    _safe_name(project, "project")
    mode = _mode(args, default="mock")
    max_repairs = int(args.get("max_repairs", 5))
    result = await SessionController().run(
        prompt,
        project=project,
        mode=mode,
        options=_session_options(
            mode=mode,
            project=project,
            max_repairs=max_repairs,
            dry_run=dry_run,
        ),
    )
    return result.model_dump(mode="json")


async def _list_sessions_tool(args: JsonDict) -> JsonDict:
    project = _optional_str(args, "project")
    if project:
        _safe_name(project, "project")
    limit = int(args.get("limit", 20))
    sessions: list[JsonDict] = []
    projects = [project] if project else [path.name for path in sorted((WORKSPACE_ROOT / "projects").glob("*")) if path.is_dir()]
    for project_name in projects:
        root = WORKSPACE_ROOT / "projects" / str(project_name) / "sessions"
        if not root.exists():
            continue
        for session_dir in sorted(root.iterdir(), key=lambda item: item.name, reverse=True):
            if not session_dir.is_dir():
                continue
            journal_path = session_dir / "session_journal.json"
            journal = _read_json(journal_path) if journal_path.exists() else {}
            sessions.append(
                {
                    "project": project_name,
                    "session_id": session_dir.name,
                    "path": str(session_dir),
                    "final_status": journal.get("final_status"),
                    "summary": journal.get("summary"),
                    "artifacts": sorted(path.name for path in session_dir.iterdir() if path.is_file()),
                }
            )
    return {"sessions": sessions[:limit]}


async def _read_session_artifact_tool(args: JsonDict) -> JsonDict:
    project = _required_str(args, "project")
    session_id = _required_str(args, "session_id")
    artifact = _required_str(args, "artifact")
    if artifact not in SESSION_ARTIFACTS:
        raise ValueError(f"artifact is not allowlisted: {artifact}")
    path = _session_dir(project, session_id) / artifact
    if not path.exists():
        raise FileNotFoundError(path)
    content = path.read_text(encoding="utf-8")
    return {"path": str(path), "artifact": artifact, "content": content, "json": _try_json(content)}


async def _read_trace_tool(args: JsonDict) -> JsonDict:
    project = _required_str(args, "project")
    session_id = _required_str(args, "session_id")
    limit = int(args.get("limit", 100))
    path = _session_dir(project, session_id) / "tool_trace.jsonl"
    if not path.exists():
        raise FileNotFoundError(path)
    events = [_try_json(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    return {"path": str(path), "events": events[-limit:], "event_count": len(events)}


async def _plan_spec_tool(args: JsonDict) -> JsonDict:
    project = _optional_str(args, "project") or "opencode"
    _safe_name(project, "project")
    spec, metadata = await _plan_spec(_required_str(args, "prompt"), project)
    return {"cad_spec": spec.model_dump(mode="json"), "cad_spec_json": spec.to_json_text(), **metadata}


async def _validate_spec_tool(args: JsonDict) -> JsonDict:
    try:
        spec = CadSpec.model_validate_json(_required_str(args, "spec_json"))
    except Exception as exc:  # noqa: BLE001 - validator diagnostics
        return {"valid": False, "error": f"{type(exc).__name__}: {exc}"}
    return {"valid": True, "cad_spec": spec.model_dump(mode="json")}


async def _export_spec_json_tool(args: JsonDict) -> JsonDict:
    project = _optional_str(args, "project") or "opencode"
    _safe_name(project, "project")
    spec, metadata = await _plan_spec(_required_str(args, "prompt"), project)
    output_path = _optional_str(args, "output_path")
    payload: JsonDict = {"cad_spec": spec.model_dump(mode="json"), "cad_spec_json": spec.to_json_text(), **metadata}
    if output_path:
        path = _safe_relative_path(OUTPUTS_ROOT, output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(spec.to_json_text(), encoding="utf-8")
        payload["path"] = str(path)
    return payload


async def _list_benchmarks_tool(_: JsonDict) -> JsonDict:
    suites = []
    for path in sorted(BENCHMARK_ROOT.glob("*.md")):
        suites.append(
            {
                "name": path.name,
                "path": str(path),
                "case_count": len(load_benchmark_cases(path)),
            }
        )
    return {"suites": suites}


async def _run_benchmark_tool(args: JsonDict) -> JsonDict:
    suite = _safe_relative_path(BENCHMARK_ROOT, _optional_str(args, "suite") or "v0_parametric_parts.md")
    mode = _mode(args, default="mock")
    dry_run = bool(args.get("dry_run", False))
    project = _optional_str(args, "project") or "opencode_benchmarks"
    _safe_name(project, "project")
    runner = BenchmarkRunner(
        workspace_root=WORKSPACE_ROOT,
        output_dir=OUTPUTS_ROOT,
        manifest_dir=MANIFEST_ROOT,
    )
    results = await runner.run(suite, mode=mode, project=project, dry_run=dry_run)
    report_path = runner.write_report(results, OUTPUTS_ROOT / "benchmark_report.json")
    return {"report_path": str(report_path), "results": [result.model_dump(mode="json") for result in results]}


async def _read_benchmark_report_tool(args: JsonDict) -> JsonDict:
    path_arg = _optional_str(args, "path") or "benchmark_report.json"
    path = _safe_relative_path(OUTPUTS_ROOT, path_arg)
    if not path.exists():
        raise FileNotFoundError(path)
    return {"path": str(path), "report": _read_json(path)}


async def _discover_tools_tool(args: JsonDict) -> JsonDict:
    mode = _mode(args, default="real")
    manifest = await SessionController().discover_tools(mode=mode, options=_session_options(mode=mode))
    return manifest.model_dump(mode="json")


async def _propose_mapping_tool(_: JsonDict) -> JsonDict:
    return _tools_propose_mapping()


async def _read_manifest_tool(args: JsonDict) -> JsonDict:
    path_arg = _optional_str(args, "path")
    if path_arg:
        path = _safe_relative_path(MANIFEST_ROOT, path_arg)
    else:
        path = MANIFEST_ROOT / "fusion_mcp_tools_latest.json"
    if not path.exists():
        return {"loaded": False, "path": str(path), "manifest": None}
    return {"loaded": True, "path": str(path), "manifest": _read_json(path)}


async def _memory_search_tool(args: JsonDict) -> JsonDict:
    query = _required_str(args, "query")
    project = _optional_str(args, "project") or "opencode"
    _safe_name(project, "project")
    store = MemoryStore(workspace_root=WORKSPACE_ROOT)
    store.seed_global()
    records = MemoryGate().filter(MemoryRetriever(store).retrieve(query, project=project), query)
    return {"records": [record.model_dump(mode="json") for record in records]}


async def _memory_write_tool(args: JsonDict) -> JsonDict:
    project = _required_str(args, "project")
    _safe_name(project, "project")
    relative_path = _required_str(args, "path")
    content = _required_str(args, "content")
    if Path(relative_path).is_absolute() or ".." in Path(relative_path).parts:
        raise ValueError("memory path must be relative and stay under the project memory root")
    path = MemoryStore(workspace_root=WORKSPACE_ROOT).write_project_markdown(project, relative_path, content)
    return {"path": str(path)}


async def _memory_list_project_tool(args: JsonDict) -> JsonDict:
    project = _optional_str(args, "project") or "opencode"
    _safe_name(project, "project")
    store = MemoryStore(workspace_root=WORKSPACE_ROOT)
    store.seed_global()
    records = store.iter_records(project=project)
    return {"records": [record.model_dump(mode="json") for record in records]}


async def _skills_list_tool(_: JsonDict) -> JsonDict:
    skills = SkillLoader().load().all()
    return {"skills": [_skill_payload(skill, include_content=False) for skill in skills]}


async def _skills_get_tool(args: JsonDict) -> JsonDict:
    skill = SkillLoader().load().get(_required_str(args, "name"))
    if skill is None:
        raise KeyError(args["name"])
    return {"skill": _skill_payload(skill, include_content=True)}


async def _skills_rank_tool(args: JsonDict) -> JsonDict:
    registry = SkillLoader().load()
    ranked = SkillRouter(registry).rank(_required_str(args, "query"), limit=int(args.get("limit", 3)))
    return {"skills": [_skill_payload(skill, include_content=False) for skill in ranked]}


async def _plan_spec(prompt: str, project: str) -> tuple[CadSpec, JsonDict]:
    store = MemoryStore(workspace_root=WORKSPACE_ROOT)
    store.seed_global()
    retrieved = MemoryRetriever(store).retrieve(prompt, project=project)
    gated_memory = MemoryGate().filter(retrieved, prompt)
    ranked_skills = SkillRouter(SkillLoader().load()).rank(prompt)
    spec = await RuleBasedPlanner().plan(
        PlanningRequest(
            user_prompt=prompt,
            project=project,
            memory=gated_memory,
            skills=[skill.name for skill in ranked_skills],
        )
    )
    return (
        spec,
        {
            "project": project,
            "memory_records": [record.model_dump(mode="json") for record in gated_memory],
            "skills": [_skill_payload(skill, include_content=False) for skill in ranked_skills],
        },
    )


def _tool_spec_map() -> dict[str, ToolSpec]:
    return {spec.name: spec for spec in tool_specs()}


def _session_options(
    *,
    mode: str,
    project: str = "opencode",
    max_repairs: int = 5,
    dry_run: bool = False,
) -> SessionOptions:
    return SessionOptions(
        mode=mode,
        project=project,
        max_repairs=max_repairs,
        workspace_root=WORKSPACE_ROOT,
        output_dir=OUTPUTS_ROOT,
        manifest_dir=MANIFEST_ROOT,
        dry_run=dry_run,
    )


def _skill_payload(skill: Any, *, include_content: bool) -> JsonDict:
    payload = skill.model_dump(mode="json")
    if not include_content:
        payload.pop("content", None)
    return payload


def _mode(args: JsonDict, *, default: str) -> str:
    value = str(args.get("mode", default))
    if value not in {"mock", "real"}:
        raise ValueError("mode must be 'mock' or 'real'")
    return value


def _required_str(args: JsonDict, key: str) -> str:
    value = args.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{key} is required")
    return value


def _optional_str(args: JsonDict, key: str) -> str | None:
    value = args.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string")
    return value


def _session_dir(project: str, session_id: str) -> Path:
    _safe_name(project, "project")
    _safe_name(session_id, "session_id")
    return WORKSPACE_ROOT / "projects" / project / "sessions" / session_id


def _safe_name(value: str, label: str) -> None:
    if not value or any(part in value for part in ("/", "\\", "..")):
        raise ValueError(f"{label} must be a simple path segment")


def _safe_relative_path(root: Path, value: str) -> Path:
    path = Path(value)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("path must be relative and must not contain '..'")
    if path.parts and path.parts[0] == root.name:
        path = Path(*path.parts[1:]) if len(path.parts) > 1 else Path()
    return root / path


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _try_json(value: str) -> Any:
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return None


def _json_text(payload: Any) -> str:
    return json.dumps(_jsonable(payload), indent=2, sort_keys=True)


def _jsonable(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {key: _jsonable(child) for key, child in value.items()}
    if isinstance(value, list | tuple):
        return [_jsonable(child) for child in value]
    return value


def _schema(properties: JsonDict | None = None, required: list[str] | None = None) -> JsonDict:
    return {
        "type": "object",
        "properties": properties or {},
        "required": required or [],
        "additionalProperties": False,
    }


def _string() -> JsonDict:
    return {"type": "string"}


def _boolean(default: bool | None = None) -> JsonDict:
    schema: JsonDict = {"type": "boolean"}
    if default is not None:
        schema["default"] = default
    return schema


def _integer(minimum: int | None = None, maximum: int | None = None, default: int | None = None) -> JsonDict:
    schema: JsonDict = {"type": "integer"}
    if minimum is not None:
        schema["minimum"] = minimum
    if maximum is not None:
        schema["maximum"] = maximum
    if default is not None:
        schema["default"] = default
    return schema


def _mode_schema(default: str = "mock") -> JsonDict:
    return _schema({"mode": {"type": "string", "enum": ["mock", "real"], "default": default}})


def _run_schema() -> JsonDict:
    return _schema(
        {
            "prompt": _string(),
            "mode": {"type": "string", "enum": ["mock", "real"], "default": "mock"},
            "project": _string(),
            "max_repairs": _integer(0, 20, 5),
            "dry_run": _boolean(False),
        },
        ["prompt"],
    )


def _dry_run_schema() -> JsonDict:
    return _schema(
        {
            "prompt": _string(),
            "mode": {"type": "string", "enum": ["mock", "real"], "default": "mock"},
            "project": _string(),
            "max_repairs": _integer(0, 20, 5),
        },
        ["prompt"],
    )


def _verify_schema() -> JsonDict:
    return _schema(
        {
            "prompt": _string(),
            "mode": {"type": "string", "enum": ["mock", "real"], "default": "mock"},
            "project": _string(),
        },
        ["prompt"],
    )


def _capture_schema() -> JsonDict:
    return _schema(
        {
            "mode": {"type": "string", "enum": ["mock", "real"], "default": "mock"},
            "project": _string(),
            "output_dir": _string(),
            "name": _string(),
            "view": {"type": "string", "enum": ["isometric", "front", "top", "right"], "default": "isometric"},
            "isolate_prefix": _string(),
            "width": _integer(64, 10000, 1600),
            "height": _integer(64, 10000, 1100),
        }
    )


def _read_artifact_schema() -> JsonDict:
    return _schema(
        {
            "project": _string(),
            "session_id": _string(),
            "artifact": {"type": "string", "enum": sorted(SESSION_ARTIFACTS)},
        },
        ["project", "session_id", "artifact"],
    )


def _read_trace_schema() -> JsonDict:
    return _schema(
        {"project": _string(), "session_id": _string(), "limit": _integer(1, 1000, 100)},
        ["project", "session_id"],
    )


def _plan_schema() -> JsonDict:
    return _schema({"prompt": _string(), "project": _string()}, ["prompt"])


def _export_spec_schema() -> JsonDict:
    return _schema({"prompt": _string(), "project": _string(), "output_path": _string()}, ["prompt"])


def _benchmark_schema() -> JsonDict:
    return _schema(
        {
            "suite": _string(),
            "mode": {"type": "string", "enum": ["mock", "real"], "default": "mock"},
            "project": _string(),
            "dry_run": _boolean(False),
        }
    )


def _memory_search_schema() -> JsonDict:
    return _schema({"query": _string(), "project": _string()}, ["query"])


def _memory_write_schema() -> JsonDict:
    return _schema({"project": _string(), "path": _string(), "content": _string()}, ["project", "path", "content"])


if __name__ == "__main__":
    raise SystemExit(main())
