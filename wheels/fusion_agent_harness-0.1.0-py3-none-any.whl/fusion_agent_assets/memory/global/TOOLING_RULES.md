# Tooling Rules

- Raw MCP tools are not exposed directly to executor.
- Tool discovery manifest must be saved.
- Unknown tools are blocked.
- Sensitive operations require confirmation policy.
- Each tool call is logged.
- Tool result schemas are validated when available.
- Timeouts are mandatory.
