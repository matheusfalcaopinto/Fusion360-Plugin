# Global Failure Patterns

## UNIT_MISMATCH

Symptom: bounding box is off by factor like 10, 2.54 or 25.4.

Detection: compare measured dimensions to expected dimensions.

Repair: inspect parameter expressions and replace ambiguous values with explicit unit strings.

## OPEN_PROFILE

Symptom: extrude cannot find profile or sketch profile count is zero.

Detection: validate closed profiles before extrusion.

Repair: rebuild sketch using constrained helper operation or apply coincident constraints.

## WRONG_ACTIVE_COMPONENT

Symptom: body/feature created under unexpected component.

Detection: compare created object's parent component to target component.

Repair: activate target component or move object only if safe.
