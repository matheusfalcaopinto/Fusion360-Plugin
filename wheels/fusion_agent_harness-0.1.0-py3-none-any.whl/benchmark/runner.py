"""Benchmark runner."""

from __future__ import annotations

import json
import time
from pathlib import Path

from agent_core.session_controller import SessionController, SessionOptions
from benchmark.loader import load_benchmark_cases
from benchmark.models import BenchmarkResult


class BenchmarkRunner:
    """Run benchmark suites through the normal session controller."""

    def __init__(
        self,
        controller: SessionController | None = None,
        workspace_root: Path | str = "workspace",
        output_dir: Path | str = "outputs",
        manifest_dir: Path | str = "manifests",
    ) -> None:
        self.controller = controller or SessionController()
        self.workspace_root = Path(workspace_root)
        self.output_dir = Path(output_dir)
        self.manifest_dir = Path(manifest_dir)

    async def run(
        self,
        suite_path: Path | str,
        mode: str = "mock",
        project: str = "benchmarks",
        dry_run: bool = False,
    ) -> list[BenchmarkResult]:
        """Run all cases in a suite."""

        cases = load_benchmark_cases(suite_path)
        results: list[BenchmarkResult] = []
        for case in cases:
            started = time.perf_counter()
            session = await self.controller.run(
                case.prompt,
                project=project,
                mode=mode,
                options=SessionOptions(
                    mode=mode,
                    project=project,
                    workspace_root=self.workspace_root,
                    output_dir=self.output_dir,
                    manifest_dir=self.manifest_dir,
                    dry_run=dry_run,
                ),
            )
            duration_ms = int((time.perf_counter() - started) * 1000)
            results.append(
                BenchmarkResult(
                    id=case.id,
                    prompt=case.prompt,
                    status=session.status,
                    first_pass_success=session.verification.passed and not session.repair_attempts,
                    final_success=session.verification.passed,
                    repair_loop_count=len(session.repair_attempts),
                    metrics={**session.verification.metrics, "session_duration_ms": duration_ms},
                    journal_path=session.journal_path,
                )
            )
        return results

    def write_report(self, results: list[BenchmarkResult], path: Path | str) -> Path:
        """Write benchmark results to JSON."""

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = [result.model_dump(mode="json") for result in results]
        path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        return path
