"""Benchmark models."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class BenchmarkCase(BaseModel):
    """One benchmark prompt and expected metadata."""

    id: str
    prompt: str
    expected: dict[str, Any] = Field(default_factory=dict)


class BenchmarkResult(BaseModel):
    """One benchmark execution result."""

    id: str
    prompt: str
    status: str
    first_pass_success: bool
    final_success: bool
    repair_loop_count: int
    metrics: dict[str, Any] = Field(default_factory=dict)
    journal_path: Path | None = None

    model_config = {"arbitrary_types_allowed": True}

