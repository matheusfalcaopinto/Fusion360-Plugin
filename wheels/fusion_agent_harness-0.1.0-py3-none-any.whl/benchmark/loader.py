"""Benchmark case loader."""

from __future__ import annotations

import re
from pathlib import Path

from benchmark.fixtures import V0_PARAMETRIC_PARTS
from benchmark.models import BenchmarkCase


def load_benchmark_cases(path: Path | str) -> list[BenchmarkCase]:
    """Load benchmark prompts from Markdown or return built-in v0 fixtures."""

    path = Path(path)
    if path.is_dir():
        markdown = path / "v0_parametric_parts.md"
        if markdown.exists():
            path = markdown
    if not path.exists():
        return list(V0_PARAMETRIC_PARTS)
    text = path.read_text(encoding="utf-8")
    cases: list[BenchmarkCase] = []
    for match in re.finditer(r"^##\s+([a-zA-Z0-9_]+)\s*(.*?)(?=^##\s+|\Z)", text, flags=re.MULTILINE | re.DOTALL):
        case_id = match.group(1).strip()
        block = match.group(2)
        prompt_match = re.search(r">\s*(.+)", block)
        if prompt_match:
            cases.append(BenchmarkCase(id=case_id, prompt=prompt_match.group(1).strip()))
    return cases or list(V0_PARAMETRIC_PARTS)

