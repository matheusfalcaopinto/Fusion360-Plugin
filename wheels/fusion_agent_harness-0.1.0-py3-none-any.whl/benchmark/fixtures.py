"""Static benchmark fixtures used when Markdown parsing is insufficient."""

from __future__ import annotations

from benchmark.models import BenchmarkCase


V0_PARAMETRIC_PARTS = [
    BenchmarkCase(id="v0_cube_10mm", prompt="Create a 10 mm cube centered at the origin."),
    BenchmarkCase(
        id="v0_mounting_plate_4_holes",
        prompt="Create a 100 x 60 x 6 mm mounting plate with four 5 mm holes, one near each corner, 12 mm from each edge.",
    ),
    BenchmarkCase(
        id="v0_spacer",
        prompt="Create a cylindrical spacer, 20 mm outer diameter, 8 mm inner hole, 15 mm tall.",
    ),
    BenchmarkCase(
        id="v0_l_bracket",
        prompt="Create a simple L bracket with 50 mm legs, 5 mm thickness, and two 5 mm mounting holes.",
    ),
    BenchmarkCase(
        id="v0_simple_box",
        prompt="Create an open rectangular box 80 x 50 x 30 mm with 3 mm wall thickness.",
    ),
]

