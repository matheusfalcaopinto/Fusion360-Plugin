"""JSONL trace writer."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class JsonlTraceLogger:
    """Append-only JSONL trace for every native tool call."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, event: dict[str, Any]) -> None:
        """Append one event to the trace."""

        event = {"timestamp": datetime.now(timezone.utc).isoformat(), **event}
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, sort_keys=True) + "\n")

    def log_tool_call(
        self,
        session_id: str,
        facade_tool: str,
        native_tool: str,
        arguments: dict[str, Any],
        result_status: str,
        duration_ms: int,
        error_code: str | None = None,
    ) -> None:
        """Record one tool call with redacted arguments and hash."""

        redacted = {key: value for key, value in arguments.items() if not key.startswith("_")}
        serialized = json.dumps(redacted, sort_keys=True, default=str)
        self.log(
            {
                "session_id": session_id,
                "event": "tool_call",
                "facade_tool": facade_tool,
                "native_tool": native_tool,
                "arguments_hash": hashlib.sha256(serialized.encode("utf-8")).hexdigest(),
                "arguments_redacted": redacted,
                "result_status": result_status,
                "duration_ms": duration_ms,
                "error_code": error_code,
            }
        )

