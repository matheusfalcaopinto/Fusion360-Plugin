"""Project companion tools for real Fusion CAD assistance.

This module keeps the broad v0.2/v1 tool surface behind conservative wrappers:
read tools produce structured snapshots and write tools produce previews unless
the caller explicitly asks to apply a controlled real operation.
"""

from __future__ import annotations

import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agent_core.session_controller import SessionController, SessionOptions
from fusion_mcp_adapter.real_client import RealMcpClient


JsonDict = dict[str, Any]
MAX_SNAPSHOT_RECORDS = 300
MAX_SNAPSHOT_MAP_ITEMS = 600
MAX_SNAPSHOT_LIST_ITEMS = 300
MAX_SPATIAL_PAIRS = 2500
MAX_STRING_CHARS = 2000

PROJECT_COMPANION_ARTIFACTS = {
    "project_snapshot.json",
    "assembly_explanation.md",
    "spatial_map.json",
    "bom.json",
    "bom.md",
    "design_review.md",
    "project_report.md",
    "drawing_plan.json",
    "exploded_view_plan.json",
    "controlled_modification_preview.json",
    "controlled_modification_result.json",
    "before_snapshot.json",
    "after_snapshot.json",
    "checkpoint.json",
    "script_plan.json",
}

STANDARD_COMPONENTS: list[JsonDict] = [
    {"kind": "fastener", "family": "socket_head_cap_screw", "aliases": ["bolt", "screw", "parafuso"], "generated": True},
    {"kind": "fastener", "family": "hex_nut", "aliases": ["nut", "porca"], "generated": True},
    {"kind": "fastener", "family": "washer", "aliases": ["washer", "arruela"], "generated": True},
    {"kind": "bearing", "family": "deep_groove_ball_bearing", "aliases": ["bearing", "rolamento"], "generated": True},
    {"kind": "motor", "family": "nema17_stepper", "aliases": ["nema", "motor", "stepper"], "generated": True},
    {"kind": "profile", "family": "2020_aluminum_extrusion", "aliases": ["2020", "profile", "perfil"], "generated": True},
    {"kind": "profile", "family": "3030_aluminum_extrusion", "aliases": ["3030", "profile", "perfil"], "generated": True},
    {"kind": "linear_motion", "family": "mgn12_linear_rail", "aliases": ["mgn12", "rail", "trilho"], "generated": True},
    {"kind": "powertrain", "family": "gt2_pulley", "aliases": ["pulley", "polia"], "generated": True},
    {"kind": "powertrain", "family": "gt2_belt", "aliases": ["belt", "correia"], "generated": True},
    {"kind": "sensor", "family": "limit_switch", "aliases": ["sensor", "switch", "fim de curso"], "generated": True},
    {"kind": "electronics", "family": "electronics_plate", "aliases": ["pcb", "placa", "electronics"], "generated": True},
    {"kind": "cooling", "family": "axial_fan", "aliases": ["fan", "ventoinha"], "generated": True},
    {"kind": "gear", "family": "spur_gear", "aliases": ["gear", "engrenagem"], "generated": True},
]

_READ_TOOL_NAMES = {
    "fusion_agent_list_projects",
    "fusion_agent_search_documents",
    "fusion_agent_list_open_documents",
    "fusion_agent_list_recent_documents",
    "fusion_agent_search_fusion_api_docs",
    "fusion_agent_analyze_project",
    "fusion_agent_explain_assembly",
    "fusion_agent_spatial_map",
    "fusion_agent_find_root_bodies",
    "fusion_agent_find_loose_components",
    "fusion_agent_find_unused_parts",
    "fusion_agent_find_alignment_issues",
    "fusion_agent_find_interferences",
    "fusion_agent_measure_clearances",
    "fusion_agent_motion_envelope_check",
    "fusion_agent_find_library_components",
    "fusion_agent_preview_modification",
    "fusion_agent_compare_before_after",
    "fusion_agent_list_materials",
    "fusion_agent_list_appearances",
    "fusion_agent_analyze_sketches",
    "fusion_agent_generate_bom",
    "fusion_agent_generate_design_review",
    "fusion_agent_generate_project_report",
}

_WRITE_TOOL_NAMES = {
    "fusion_agent_open_document",
    "fusion_agent_save_document",
    "fusion_agent_close_document",
    "fusion_agent_close_without_save",
    "fusion_agent_undo",
    "fusion_agent_redo",
    "fusion_agent_create_checkpoint",
    "fusion_agent_apply_controlled_modification",
    "fusion_agent_execute_approved_script",
    "fusion_agent_insert_existing_component",
    "fusion_agent_generate_standard_component",
    "fusion_agent_place_component",
    "fusion_agent_move_component",
    "fusion_agent_align_component",
    "fusion_agent_pattern_component",
    "fusion_agent_create_rigid_group",
    "fusion_agent_create_joint",
    "fusion_agent_set_joint_limits",
    "fusion_agent_add_fasteners_to_holes",
    "fusion_agent_organize_component_tree",
    "fusion_agent_delete_unused_parts",
    "fusion_agent_apply_material",
    "fusion_agent_apply_appearance",
    "fusion_agent_set_part_metadata",
    "fusion_agent_repair_sketch",
    "fusion_agent_constrain_sketch",
    "fusion_agent_create_parametric_part",
    "fusion_agent_modify_parametric_feature",
    "fusion_agent_create_adapter_part",
    "fusion_agent_create_part_drawing",
    "fusion_agent_create_assembly_drawing",
    "fusion_agent_create_exploded_view",
    "fusion_agent_export_pdf",
    "fusion_agent_export_dxf",
}


def companion_tool_specs() -> list[JsonDict]:
    """Return v0.2/v1 companion tool metadata."""

    return [
        _tool("fusion_agent_list_projects", "List Fusion projects/hubs through the safe read wrapper.", _mode_schema()),
        _tool("fusion_agent_search_documents", "Search Fusion documents by name.", _schema({"mode": _mode_prop(), "name": _string(), "project": _string()}, ["name"])),
        _tool("fusion_agent_list_open_documents", "List open Fusion documents.", _mode_schema()),
        _tool("fusion_agent_list_recent_documents", "List recent Fusion documents.", _mode_schema()),
        _tool("fusion_agent_open_document", "Open a Fusion document by file id.", _schema({"mode": _mode_prop("real"), "file_id": _string()}, ["file_id"])),
        _tool("fusion_agent_save_document", "Save the active Fusion document with explicit confirmation.", _confirm_schema("user_confirmed_save")),
        _tool("fusion_agent_close_document", "Close the active document with explicit save/discard confirmation.", _schema({"mode": _mode_prop("real"), "user_confirmed_save_and_close": _boolean(False), "user_confirmed_close_without_save": _boolean(False)})),
        _tool("fusion_agent_close_without_save", "Close the active document without saving after explicit confirmation.", _confirm_schema("user_confirmed_close_without_save")),
        _tool("fusion_agent_search_fusion_api_docs", "Search Fusion API documentation exposed by the native MCP server.", _schema({"mode": _mode_prop("real"), "search_pattern": _string(), "api_category": {"type": "string", "enum": ["class", "member", "description", "all"], "default": "all"}, "filter": _string()}, ["search_pattern"])),
        _tool("fusion_agent_undo", "Undo the latest Fusion operation through a safe public wrapper.", _mode_schema("real")),
        _tool("fusion_agent_redo", "Redo the latest undone Fusion operation through a safe public wrapper.", _mode_schema("real")),
        _tool("fusion_agent_create_checkpoint", "Write a project checkpoint artifact with the active design snapshot.", _project_schema()),
        _tool("fusion_agent_preview_modification", "Preview a controlled modification before applying it.", _operation_schema()),
        _tool("fusion_agent_compare_before_after", "Compare two snapshots or the latest before/after artifacts.", _schema({"project": _string(), "before_path": _string(), "after_path": _string()})),
        _tool("fusion_agent_apply_controlled_modification", "Apply an approved controlled modification and record before/after snapshots.", _operation_schema(required=["operation", "allow_apply"])),
        _tool("fusion_agent_execute_approved_script", "Execute an explicitly approved safe Fusion API script.", _schema({"mode": _mode_prop("real"), "project": _string(), "purpose": _string(), "script": _string(), "approval_token": _string()}, ["purpose", "script", "approval_token"])),
        _tool("fusion_agent_analyze_project", "Analyze the active assembly/project into a ProjectSnapshot.", _project_mode_schema()),
        _tool("fusion_agent_explain_assembly", "Explain the active assembly structure and issues.", _project_mode_schema()),
        _tool("fusion_agent_spatial_map", "Build a spatial map with centers, bounding boxes, distances and clearances.", _project_mode_schema()),
        _tool("fusion_agent_find_root_bodies", "Find bodies that live directly under the root component.", _project_mode_schema()),
        _tool("fusion_agent_find_loose_components", "Find components that appear loose or empty.", _project_mode_schema()),
        _tool("fusion_agent_find_unused_parts", "Find likely unused, legacy or hidden parts.", _project_mode_schema()),
        _tool("fusion_agent_find_alignment_issues", "Find likely component alignment issues.", _project_mode_schema()),
        _tool("fusion_agent_find_interferences", "Find recorded or detectable interferences.", _project_mode_schema()),
        _tool("fusion_agent_measure_clearances", "Measure pairwise clearances from snapshot bounding boxes.", _schema({"mode": _mode_prop(), "project": _string(), "limit": _integer(1, 200, 40)})),
        _tool("fusion_agent_motion_envelope_check", "Estimate motion envelopes from joints and moving components.", _project_mode_schema()),
        _tool("fusion_agent_find_library_components", "Search existing Fusion documents and generated standard components.", _schema({"mode": _mode_prop("real"), "query": _string(), "project": _string(), "limit": _integer(1, 50, 10)}, ["query"])),
        _tool("fusion_agent_insert_existing_component", "Insert or stage a Fusion document component into the active assembly.", _component_action_schema(["file_id", "component_name"])),
        _tool("fusion_agent_generate_standard_component", "Generate or stage a standard mechanical component.", _component_action_schema(["component_type", "component_name"])),
        _tool("fusion_agent_place_component", "Place a component at an explicit XYZ offset in mm.", _component_action_schema(["component_name"])),
        _tool("fusion_agent_move_component", "Move a component by an explicit XYZ delta in mm.", _component_action_schema(["component_name"])),
        _tool("fusion_agent_align_component", "Align one component to another named target.", _component_action_schema(["component_name", "target_name"])),
        _tool("fusion_agent_pattern_component", "Pattern a component linearly.", _component_action_schema(["component_name"])),
        _tool("fusion_agent_create_rigid_group", "Create or stage a rigid group of components.", _component_action_schema(["group_name"])),
        _tool("fusion_agent_create_joint", "Create or stage a rigid/revolute/slider joint.", _component_action_schema(["joint_name", "parent", "child"])),
        _tool("fusion_agent_set_joint_limits", "Set or stage joint motion limits.", _component_action_schema(["joint_name"])),
        _tool("fusion_agent_add_fasteners_to_holes", "Add or stage generated fasteners at detected/provided holes.", _component_action_schema(["target_component"])),
        _tool("fusion_agent_organize_component_tree", "Organize components/bodies into a cleaner tree.", _component_action_schema()),
        _tool("fusion_agent_delete_unused_parts", "Delete allowlisted unused parts through a controlled operation.", _delete_schema()),
        _tool("fusion_agent_list_materials", "List available materials from the active Fusion environment.", _mode_schema("real")),
        _tool("fusion_agent_list_appearances", "List available appearances from the active Fusion environment.", _mode_schema("real")),
        _tool("fusion_agent_apply_material", "Apply a material to a component or body.", _component_action_schema(["target_name", "material"])),
        _tool("fusion_agent_apply_appearance", "Apply an appearance to a component or body.", _component_action_schema(["target_name", "appearance"])),
        _tool("fusion_agent_set_part_metadata", "Set part number, description, source type and attributes.", _component_action_schema(["target_name"])),
        _tool("fusion_agent_analyze_sketches", "Analyze sketches for closure and constraint issues.", _project_mode_schema()),
        _tool("fusion_agent_repair_sketch", "Repair or stage repair for a named sketch.", _component_action_schema(["sketch_name"])),
        _tool("fusion_agent_constrain_sketch", "Constrain or stage constraints for a named sketch.", _component_action_schema(["sketch_name"])),
        _tool("fusion_agent_create_parametric_part", "Create or stage a parametric part from a prompt.", _schema({"mode": _mode_prop(), "project": _string(), "prompt": _string(), "allow_apply": _boolean(False)}, ["prompt"])),
        _tool("fusion_agent_modify_parametric_feature", "Modify or stage modification of a named feature/parameter.", _component_action_schema(["target_name"])),
        _tool("fusion_agent_create_adapter_part", "Create or stage an adapter part between interfaces.", _schema({"mode": _mode_prop(), "project": _string(), "purpose": _string(), "interface_a": _string(), "interface_b": _string(), "allow_apply": _boolean(False)}, ["purpose"])),
        _tool("fusion_agent_create_part_drawing", "Create a part drawing plan with basic views and dimensions.", _drawing_schema(["target_name"])),
        _tool("fusion_agent_create_assembly_drawing", "Create an assembly drawing plan with BOM and views.", _drawing_schema()),
        _tool("fusion_agent_create_exploded_view", "Create an exploded-view plan and optional view capture.", _drawing_schema()),
        _tool("fusion_agent_export_pdf", "Export or stage a PDF report/drawing artifact.", _export_schema("pdf")),
        _tool("fusion_agent_export_dxf", "Export or stage a DXF drawing artifact.", _export_schema("dxf")),
        _tool("fusion_agent_generate_bom", "Generate a BOM from the active project snapshot.", _project_mode_schema()),
        _tool("fusion_agent_generate_design_review", "Generate a design review report with risks and recommendations.", _project_mode_schema()),
        _tool("fusion_agent_generate_project_report", "Generate a project report with snapshot, BOM, images and next steps.", _project_mode_schema()),
    ]


async def execute_companion_tool(
    name: str,
    args: JsonDict,
    *,
    workspace_root: Path,
    output_dir: Path,
    manifest_dir: Path,
) -> JsonDict:
    """Execute one v0.2/v1 companion tool."""

    companion = ProjectCompanion(
        mode=str(args.get("mode", "mock")),
        project=str(args.get("project", "opencode")),
        workspace_root=workspace_root,
        output_dir=output_dir,
        manifest_dir=manifest_dir,
    )
    if companion.mode not in {"mock", "real"}:
        raise ValueError("mode must be 'mock' or 'real'")
    if name in _READ_TOOL_NAMES or name in _WRITE_TOOL_NAMES:
        return await companion.execute(name, args)
    raise ValueError(f"unknown companion tool: {name}")


class ProjectCompanion:
    """High-level assistant operations for the active Fusion project."""

    def __init__(self, *, mode: str, project: str, workspace_root: Path, output_dir: Path, manifest_dir: Path) -> None:
        self.mode = mode
        self.project = _safe_segment(project or "opencode")
        self.workspace_root = Path(workspace_root)
        self.output_dir = Path(output_dir)
        self.manifest_dir = Path(manifest_dir)
        self.artifact_root = self.output_dir / "project_companion" / _safe_artifact_slug(self.project)
        self.artifact_root.mkdir(parents=True, exist_ok=True)

    async def execute(self, name: str, args: JsonDict) -> JsonDict:
        if name == "fusion_agent_list_projects":
            return await self._native_read({"queryType": "projects"})
        if name == "fusion_agent_search_documents":
            return await self._native_read({"queryType": "document", "operation": "search", "name": _required(args, "name"), **_maybe_project(args)})
        if name == "fusion_agent_list_open_documents":
            return await self._native_read({"queryType": "document", "operation": "open"})
        if name == "fusion_agent_list_recent_documents":
            return await self._native_read({"queryType": "document", "operation": "recent"})
        if name == "fusion_agent_open_document":
            return await self._native_execute({"featureType": "document", "object": {"operation": "open", "fileId": _required(args, "file_id")}})
        if name == "fusion_agent_save_document":
            if not args.get("user_confirmed_save"):
                raise ValueError("user_confirmed_save=true is required")
            return await self._native_execute({"featureType": "document", "object": {"operation": "save"}})
        if name == "fusion_agent_close_document":
            return await self._close_document(args)
        if name == "fusion_agent_close_without_save":
            if not args.get("user_confirmed_close_without_save"):
                raise ValueError("user_confirmed_close_without_save=true is required")
            return await self._native_execute({"featureType": "document", "object": {"operation": "close", "userConfirmedCloseWithoutSave": True}})
        if name == "fusion_agent_search_fusion_api_docs":
            payload = {"queryType": "apiDocumentation", "searchPattern": _required(args, "search_pattern")}
            if args.get("api_category"):
                payload["apiCategory"] = args["api_category"]
            if args.get("filter"):
                payload["filter"] = args["filter"]
            return await self._native_read(payload)
        if name == "fusion_agent_undo":
            return await self._native_update({"featureType": "undo"})
        if name == "fusion_agent_redo":
            return await self._native_update({"featureType": "redo"})
        if name == "fusion_agent_create_checkpoint":
            return await self._checkpoint()
        if name == "fusion_agent_preview_modification":
            return await self._preview_modification(args)
        if name == "fusion_agent_compare_before_after":
            return await self._compare_before_after(args)
        if name == "fusion_agent_apply_controlled_modification":
            return await self._apply_controlled_modification(args)
        if name == "fusion_agent_execute_approved_script":
            return await self._execute_approved_script(args)
        if name == "fusion_agent_analyze_project":
            return await self._analyze_project()
        if name == "fusion_agent_explain_assembly":
            return await self._explain_assembly()
        if name == "fusion_agent_spatial_map":
            return await self._spatial_map_payload()
        if name == "fusion_agent_find_root_bodies":
            return await self._finding_payload("root_bodies")
        if name == "fusion_agent_find_loose_components":
            return await self._finding_payload("loose_components")
        if name == "fusion_agent_find_unused_parts":
            return await self._finding_payload("unused_parts")
        if name == "fusion_agent_find_alignment_issues":
            return await self._finding_payload("alignment_issues")
        if name == "fusion_agent_find_interferences":
            return await self._finding_payload("interferences")
        if name == "fusion_agent_measure_clearances":
            return await self._clearances(limit=int(args.get("limit", 40)))
        if name == "fusion_agent_motion_envelope_check":
            return await self._motion_envelope()
        if name == "fusion_agent_find_library_components":
            return await self._find_library_components(_required(args, "query"), limit=int(args.get("limit", 10)))
        if name == "fusion_agent_list_materials":
            return await self._list_named_assets("materials")
        if name == "fusion_agent_list_appearances":
            return await self._list_named_assets("appearances")
        if name == "fusion_agent_analyze_sketches":
            return await self._analyze_sketches()
        if name == "fusion_agent_generate_bom":
            return await self._bom_payload()
        if name == "fusion_agent_generate_design_review":
            return await self._design_review()
        if name == "fusion_agent_generate_project_report":
            return await self._project_report()
        if name.startswith("fusion_agent_create_") and name.endswith("_drawing"):
            return await self._drawing_plan(name, args)
        if name == "fusion_agent_create_exploded_view":
            return await self._exploded_view(args)
        if name in {"fusion_agent_export_pdf", "fusion_agent_export_dxf"}:
            return await self._export_document(name, args)
        return await self._controlled_action(name, args)

    async def _inspect_state(self) -> JsonDict:
        payload = await SessionController().inspect(
            mode=self.mode,
            options=SessionOptions(
                mode=self.mode,
                project=self.project,
                workspace_root=self.workspace_root,
                output_dir=self.output_dir,
                manifest_dir=self.manifest_dir,
            ),
        )
        return payload.get("state", payload)

    async def _snapshot(self) -> JsonDict:
        state = await self._inspect_state()
        snapshot = build_project_snapshot(state, project=self.project, mode=self.mode)
        path = self._write_json("project_snapshot.json", snapshot)
        snapshot["snapshot_path"] = str(path)
        return snapshot

    async def _analyze_project(self) -> JsonDict:
        snapshot = await self._snapshot()
        return {"status": "success", "project_snapshot": snapshot, "snapshot_path": snapshot["snapshot_path"]}

    async def _explain_assembly(self) -> JsonDict:
        snapshot = await self._snapshot()
        lines = [
            "# Assembly Explanation",
            "",
            f"Project: {self.project}",
            f"Mode: {self.mode}",
            f"Components: {snapshot['counts']['components']}",
            f"Bodies: {snapshot['counts']['bodies']}",
            f"Occurrences: {snapshot['counts']['occurrences']}",
            f"Joints: {snapshot['counts']['joints']}",
            "",
            "## Findings",
        ]
        for key in ("root_bodies", "loose_components", "unused_parts", "alignment_issues", "interferences", "sketch_issues"):
            findings = snapshot["findings"].get(key, [])
            lines.append(f"- {key}: {len(findings)}")
        lines.extend(["", "## Recommendations"])
        lines.extend(f"- {item}" for item in snapshot["recommendations"])
        path = self._write_text("assembly_explanation.md", "\n".join(lines) + "\n")
        return {"status": "success", "explanation": "\n".join(lines), "explanation_path": str(path), "project_snapshot": snapshot}

    async def _spatial_map_payload(self) -> JsonDict:
        snapshot = await self._snapshot()
        spatial = snapshot["spatial_map"]
        path = self._write_json("spatial_map.json", spatial)
        return {"status": "success", "spatial_map": spatial, "spatial_map_path": str(path)}

    async def _finding_payload(self, key: str) -> JsonDict:
        snapshot = await self._snapshot()
        return {"status": "success", "finding_type": key, "findings": snapshot["findings"].get(key, []), "project_snapshot": snapshot}

    async def _clearances(self, *, limit: int) -> JsonDict:
        snapshot = await self._snapshot()
        clearances = snapshot["spatial_map"]["clearances"][:limit]
        return {"status": "success", "clearances": clearances, "count": len(clearances), "project_snapshot": snapshot}

    async def _motion_envelope(self) -> JsonDict:
        snapshot = await self._snapshot()
        joints = snapshot["joints"]
        envelopes = []
        for joint in joints:
            envelopes.append(
                {
                    "joint": joint.get("name"),
                    "type": joint.get("type") or joint.get("motion_type") or "unknown",
                    "axis": joint.get("axis"),
                    "limits": joint.get("limits") or {},
                    "status": "bounded" if joint.get("limits") else "limits_missing",
                }
            )
        return {"status": "success", "motion_envelopes": envelopes, "warnings": [] if envelopes else ["no motion joints found"], "project_snapshot": snapshot}

    async def _bom_payload(self) -> JsonDict:
        snapshot = await self._snapshot()
        bom = generate_bom(snapshot)
        json_path = self._write_json("bom.json", bom)
        md_path = self._write_text("bom.md", bom_to_markdown(bom))
        return {"status": "success", "bom": bom, "bom_path": str(json_path), "bom_markdown_path": str(md_path)}

    async def _design_review(self) -> JsonDict:
        snapshot = await self._snapshot()
        bom = generate_bom(snapshot)
        report = design_review_markdown(snapshot, bom)
        path = self._write_text("design_review.md", report)
        return {"status": "success", "review": report, "review_path": str(path), "project_snapshot": snapshot, "bom": bom}

    async def _project_report(self) -> JsonDict:
        snapshot = await self._snapshot()
        bom = generate_bom(snapshot)
        report = project_report_markdown(snapshot, bom)
        path = self._write_text("project_report.md", report)
        return {"status": "success", "report": report, "report_path": str(path), "project_snapshot": snapshot, "bom": bom}

    async def _analyze_sketches(self) -> JsonDict:
        snapshot = await self._snapshot()
        return {"status": "success", "sketches": snapshot["sketches"], "issues": snapshot["findings"]["sketch_issues"], "project_snapshot": snapshot}

    async def _find_library_components(self, query: str, *, limit: int) -> JsonDict:
        matches = []
        normalized = query.lower()
        for item in STANDARD_COMPONENTS:
            haystack = " ".join([item["kind"], item["family"], *item["aliases"]]).lower()
            if normalized in haystack or any(token in haystack for token in normalized.split()):
                matches.append(item)
        documents: JsonDict = {"status": "not_queried"}
        if self.mode == "real":
            try:
                documents = await self._native_read({"queryType": "document", "operation": "search", "name": query})
            except Exception as exc:  # noqa: BLE001 - document search is additive
                documents = {"status": "failed", "error": f"{type(exc).__name__}: {exc}"}
        return {
            "status": "success",
            "query": query,
            "priority_order": ["existing_fusion_documents", "generated_standard_components"],
            "document_results": documents,
            "standard_components": matches[:limit],
        }

    async def _list_named_assets(self, asset_type: str) -> JsonDict:
        if self.mode == "mock":
            return {"status": "success", asset_type: _mock_assets(asset_type)}
        script = _asset_listing_script(asset_type)
        data = await self._run_script(script)
        return {"status": "success", asset_type: data.get(asset_type, [])}

    async def _checkpoint(self) -> JsonDict:
        snapshot = await self._snapshot()
        path = self._write_json("checkpoint.json", {"created_at": _now(), "snapshot": snapshot})
        return {"status": "success", "checkpoint_path": str(path), "project_snapshot": snapshot}

    async def _preview_modification(self, args: JsonDict) -> JsonDict:
        operation = _required(args, "operation")
        before = await self._snapshot()
        preview = {
            "status": "preview",
            "operation": operation,
            "arguments": args.get("arguments") or _action_arguments(args),
            "affected_components": _affected_components(args),
            "requires_allow_apply": True,
            "before_snapshot_path": before["snapshot_path"],
        }
        path = self._write_json("controlled_modification_preview.json", preview)
        preview["preview_path"] = str(path)
        return preview

    async def _apply_controlled_modification(self, args: JsonDict) -> JsonDict:
        if not args.get("allow_apply"):
            raise ValueError("allow_apply=true is required")
        operation = _required(args, "operation")
        before = await self._snapshot()
        result = await self._apply_known_operation(operation, args.get("arguments") or args)
        after = await self._snapshot()
        comparison = compare_snapshots(before, after)
        payload = {
            "status": "applied" if result.get("executed") else "previewed",
            "operation": operation,
            "native_result": result,
            "before_snapshot_path": before["snapshot_path"],
            "after_snapshot_path": after["snapshot_path"],
            "comparison": comparison,
            "rollback": {"available": True, "method": "fusion_agent_undo"},
        }
        path = self._write_json("controlled_modification_result.json", payload)
        payload["result_path"] = str(path)
        return payload

    async def _compare_before_after(self, args: JsonDict) -> JsonDict:
        before = _load_optional_json(args.get("before_path"))
        after = _load_optional_json(args.get("after_path"))
        if before is None or after is None:
            snapshot = await self._snapshot()
            before = before or snapshot
            after = after or snapshot
        return {"status": "success", "comparison": compare_snapshots(before, after)}

    async def _execute_approved_script(self, args: JsonDict) -> JsonDict:
        if args.get("approval_token") != "APPROVED_SAFE_SCRIPT":
            raise ValueError("approval_token must be APPROVED_SAFE_SCRIPT")
        script = _required(args, "script")
        if _looks_dangerous_script(script):
            raise ValueError("script contains blocked operations")
        plan_path = self._write_json("script_plan.json", {"purpose": _required(args, "purpose"), "script_preview": script[:2000]})
        if self.mode == "mock":
            return {"status": "preview", "executed": False, "script_plan_path": str(plan_path)}
        result = await self._run_script(script)
        return {"status": "success", "executed": True, "script_plan_path": str(plan_path), "native_result": result}

    async def _controlled_action(self, name: str, args: JsonDict) -> JsonDict:
        operation = name.removeprefix("fusion_agent_")
        merged = {"operation": operation, **args}
        if not args.get("allow_apply"):
            return await self._preview_modification(merged)
        return await self._apply_controlled_modification(merged)

    async def _drawing_plan(self, name: str, args: JsonDict) -> JsonDict:
        snapshot = await self._snapshot()
        drawing = {
            "type": name.removeprefix("fusion_agent_create_"),
            "target": args.get("target_name") or "active_assembly",
            "views": ["front", "top", "right", "isometric"],
            "dimensions": "basic bounding-box dimensions",
            "bom_included": name == "fusion_agent_create_assembly_drawing",
            "exports": ["pdf", "dxf"],
            "project_snapshot_path": snapshot["snapshot_path"],
        }
        path = self._write_json("drawing_plan.json", drawing)
        return {"status": "planned", "drawing": drawing, "drawing_plan_path": str(path)}

    async def _exploded_view(self, args: JsonDict) -> JsonDict:
        snapshot = await self._snapshot()
        components = [component["name"] for component in snapshot["components"] if component["name"] != "root"]
        steps = [{"component": name, "direction": "z", "offset_mm": (index + 1) * 20} for index, name in enumerate(components)]
        payload = {"status": "planned", "steps": steps, "project_snapshot_path": snapshot["snapshot_path"]}
        path = self._write_json("exploded_view_plan.json", payload)
        payload["exploded_view_plan_path"] = str(path)
        return payload

    async def _export_document(self, name: str, args: JsonDict) -> JsonDict:
        extension = "pdf" if name.endswith("_pdf") else "dxf"
        output_name = _simple_filename(args.get("output_name") or f"export.{extension}", extension)
        path = self.artifact_root / output_name
        content = f"Fusion Agent {extension.upper()} export placeholder for {self.project}\nGenerated: {_now()}\n"
        path.write_text(content, encoding="utf-8")
        return {"status": "success", "export_path": str(path), "format": extension, "native_export": False}

    async def _close_document(self, args: JsonDict) -> JsonDict:
        save = bool(args.get("user_confirmed_save_and_close"))
        discard = bool(args.get("user_confirmed_close_without_save"))
        if save == discard:
            raise ValueError("choose exactly one close confirmation")
        payload = {"featureType": "document", "object": {"operation": "close"}}
        payload["object"]["userConfirmedSaveAndClose" if save else "userConfirmedCloseWithoutSave"] = True
        return await self._native_execute(payload)

    async def _native_read(self, payload: JsonDict) -> JsonDict:
        if self.mode == "mock":
            return {"status": "success", "mock": True, "request": payload, **_mock_native_read(payload)}
        return await _call_real_tool("fusion_mcp_read", payload)

    async def _native_execute(self, payload: JsonDict) -> JsonDict:
        if self.mode == "mock":
            return {"status": "success", "mock": True, "request": payload}
        return await _call_real_tool("fusion_mcp_execute", payload)

    async def _native_update(self, payload: JsonDict) -> JsonDict:
        if self.mode == "mock":
            return {"status": "success", "mock": True, "request": payload, "canUndo": True, "canRedo": True}
        return await _call_real_tool("fusion_mcp_update", payload)

    async def _run_script(self, script: str) -> JsonDict:
        return await self._native_execute({"featureType": "script", "object": {"script": script}})

    async def _apply_known_operation(self, operation: str, args: JsonDict) -> JsonDict:
        if self.mode == "mock":
            return {"executed": False, "mock": True, "operation": operation, "arguments": args}
        script = script_for_operation(operation, args)
        if not script:
            return {"executed": False, "reason": "operation has no approved real script wrapper", "operation": operation}
        result = await self._run_script(script)
        return {"executed": True, "operation": operation, "result": result}

    def _write_json(self, filename: str, payload: JsonDict) -> Path:
        path = self.artifact_root / filename
        safe_payload = _json_safe(payload, depth=8, max_items=MAX_SNAPSHOT_MAP_ITEMS)
        path.write_text(json.dumps(safe_payload, indent=2, sort_keys=True), encoding="utf-8")
        return path

    def _write_text(self, filename: str, content: str) -> Path:
        path = self.artifact_root / filename
        path.write_text(content, encoding="utf-8")
        return path


def build_project_snapshot(state: JsonDict, *, project: str, mode: str) -> JsonDict:
    components = _component_records(state)
    bodies = _body_records(state)
    occurrences = _occurrence_records(state)
    sketches = _sketch_records(state)
    joints = _dict_records(state.get("joints", {}))
    spatial = build_spatial_map(bodies, occurrences)
    findings = {
        "root_bodies": [body for body in bodies if body.get("component") in {"root", "", None}],
        "loose_components": _loose_components(components, occurrences),
        "unused_parts": _unused_parts(components, bodies),
        "alignment_issues": _alignment_issues(spatial),
        "interferences": _interference_findings(state),
        "sketch_issues": _sketch_issues(sketches),
    }
    recommendations = _recommendations(findings)
    return {
        "project": project,
        "mode": mode,
        "created_at": _now(),
        "units": state.get("units", "mm"),
        "active_document": bool(state.get("active_document", False)),
        "root_component": state.get("root_component", "root"),
        "active_component": state.get("active_component", "root"),
        "counts": {
            "components": len(components),
            "bodies": len(bodies),
            "occurrences": len(occurrences),
            "sketches": len(sketches),
            "joints": len(joints),
        },
        "components": components,
        "bodies": bodies,
        "occurrences": occurrences,
        "sketches": sketches,
        "joints": joints,
        "parameters": _compact_mapping(state.get("parameters", {})),
        "materials": _compact_mapping(state.get("component_metadata", {})),
        "physical_properties": _compact_mapping(state.get("physical_properties", {})),
        "spatial_map": spatial,
        "findings": findings,
        "recommendations": recommendations,
    }


def build_spatial_map(bodies: list[JsonDict], occurrences: list[JsonDict]) -> JsonDict:
    entities = []
    for body in bodies:
        bbox = _bbox(body)
        center = _center(body)
        entities.append({"type": "body", "name": body["name"], "component": body.get("component"), "bounding_box_mm": bbox, "center_mm": center})
    for occurrence in occurrences:
        bbox = _bbox(occurrence)
        center = _center(occurrence)
        entities.append({"type": "occurrence", "name": occurrence["name"], "component": occurrence.get("component"), "bounding_box_mm": bbox, "center_mm": center})
    distances = []
    clearances = []
    pair_limit_hit = False
    for left_index, left in enumerate(entities):
        for right in entities[left_index + 1 :]:
            if len(distances) >= MAX_SPATIAL_PAIRS and len(clearances) >= MAX_SPATIAL_PAIRS:
                pair_limit_hit = True
                break
            if not left.get("center_mm") or not right.get("center_mm"):
                continue
            center_distance = _distance(left["center_mm"], right["center_mm"])
            if len(distances) < MAX_SPATIAL_PAIRS:
                distances.append({"a": left["name"], "b": right["name"], "center_distance_mm": round(center_distance, 4)})
            clearance = _clearance(left.get("bounding_box_mm"), right.get("bounding_box_mm"))
            if clearance is not None and len(clearances) < MAX_SPATIAL_PAIRS:
                clearances.append({"a": left["name"], "b": right["name"], "clearance_mm": round(clearance, 4)})
        if pair_limit_hit:
            break
    return {
        "entities": entities,
        "assembly_envelope_mm": _assembly_envelope(entities),
        "distances": sorted(distances, key=lambda item: item["center_distance_mm"]),
        "clearances": sorted(clearances, key=lambda item: item["clearance_mm"]),
        "truncated_pairs": pair_limit_hit,
    }


def generate_bom(snapshot: JsonDict) -> JsonDict:
    rows = []
    for component in snapshot["components"]:
        name = component["name"]
        if name == "root":
            continue
        metadata = component.get("metadata") or {}
        body_count = len(component.get("bodies") or [])
        rows.append(
            {
                "component": name,
                "quantity": 1,
                "body_count": body_count,
                "part_number": metadata.get("part_number") or metadata.get("partNumber") or name,
                "description": metadata.get("description") or "",
                "material": metadata.get("physical_material") or metadata.get("material") or "unspecified",
                "source_type": metadata.get("source_type") or "custom",
                "mass_kg": _mass_for_component(snapshot, name),
            }
        )
    if not rows and snapshot["bodies"]:
        rows.append({"component": "root_bodies", "quantity": len(snapshot["bodies"]), "body_count": len(snapshot["bodies"]), "part_number": "root_bodies", "description": "Bodies not assigned to dedicated components", "material": "unspecified", "source_type": "custom", "mass_kg": None})
    return {"created_at": _now(), "project": snapshot["project"], "rows": rows, "totals": {"line_count": len(rows), "quantity": sum(row["quantity"] for row in rows)}}


def bom_to_markdown(bom: JsonDict) -> str:
    lines = ["# BOM", "", "| Component | Qty | Material | Source | Mass kg |", "| --- | ---: | --- | --- | ---: |"]
    for row in bom["rows"]:
        mass = "" if row.get("mass_kg") is None else str(row["mass_kg"])
        lines.append(f"| {row['component']} | {row['quantity']} | {row['material']} | {row['source_type']} | {mass} |")
    return "\n".join(lines) + "\n"


def design_review_markdown(snapshot: JsonDict, bom: JsonDict) -> str:
    lines = ["# Design Review", "", f"Project: {snapshot['project']}", "", "## Findings"]
    for key, findings in snapshot["findings"].items():
        lines.append(f"- {key}: {len(findings)}")
    lines.extend(["", "## Manufacturing Readiness"])
    lines.append(f"- components_without_material: {sum(1 for row in bom['rows'] if row['material'] == 'unspecified')}")
    lines.append(f"- root_bodies: {len(snapshot['findings']['root_bodies'])}")
    lines.append(f"- sketch_issues: {len(snapshot['findings']['sketch_issues'])}")
    lines.extend(["", "## Recommendations"])
    lines.extend(f"- {item}" for item in snapshot["recommendations"])
    return "\n".join(lines) + "\n"


def project_report_markdown(snapshot: JsonDict, bom: JsonDict) -> str:
    lines = [
        "# Fusion Agent Project Report",
        "",
        f"Project: {snapshot['project']}",
        f"Generated: {_now()}",
        "",
        "## Summary",
        f"- Components: {snapshot['counts']['components']}",
        f"- Bodies: {snapshot['counts']['bodies']}",
        f"- Occurrences: {snapshot['counts']['occurrences']}",
        f"- BOM lines: {bom['totals']['line_count']}",
        "",
        "## Warnings",
    ]
    for key, findings in snapshot["findings"].items():
        if findings:
            lines.append(f"- {key}: {len(findings)}")
    lines.extend(["", "## Next Steps"])
    lines.extend(f"- {item}" for item in snapshot["recommendations"])
    return "\n".join(lines) + "\n"


def compare_snapshots(before: JsonDict, after: JsonDict) -> JsonDict:
    return {
        "component_count_delta": after.get("counts", {}).get("components", 0) - before.get("counts", {}).get("components", 0),
        "body_count_delta": after.get("counts", {}).get("bodies", 0) - before.get("counts", {}).get("bodies", 0),
        "occurrence_count_delta": after.get("counts", {}).get("occurrences", 0) - before.get("counts", {}).get("occurrences", 0),
        "before_snapshot_path": before.get("snapshot_path"),
        "after_snapshot_path": after.get("snapshot_path"),
    }


def script_for_operation(operation: str, args: JsonDict) -> str | None:
    if operation in {"move_component", "place_component", "align_component"}:
        return _move_component_script(args)
    if operation in {"apply_material", "apply_appearance", "set_part_metadata"}:
        return _metadata_script(args)
    if operation in {"create_rigid_group", "create_joint", "set_joint_limits"}:
        return _joint_contract_script(args)
    if operation in {"insert_existing_component", "generate_standard_component", "add_fasteners_to_holes", "create_adapter_part"}:
        return _placeholder_component_script(args)
    if operation in {"organize_component_tree", "delete_unused_parts", "repair_sketch", "constrain_sketch", "modify_parametric_feature"}:
        return _attribute_marker_script(operation, args)
    return None


async def _call_real_tool(tool_name: str, payload: JsonDict) -> JsonDict:
    result = await RealMcpClient(timeout_seconds=120).call_tool(tool_name, payload)
    if not result.ok:
        raise RuntimeError(result.error_message or result.error_code or f"{tool_name} failed")
    return result.data


def _tool(name: str, description: str, schema: JsonDict) -> JsonDict:
    return {"name": name, "description": description, "schema": schema}


def _schema(properties: JsonDict | None = None, required: list[str] | None = None) -> JsonDict:
    return {"type": "object", "properties": properties or {}, "required": required or [], "additionalProperties": False}


def _mode_prop(default: str = "mock") -> JsonDict:
    return {"type": "string", "enum": ["mock", "real"], "default": default}


def _mode_schema(default: str = "mock") -> JsonDict:
    return _schema({"mode": _mode_prop(default)})


def _project_schema() -> JsonDict:
    return _schema({"mode": _mode_prop(), "project": _string()})


def _project_mode_schema() -> JsonDict:
    return _schema({"mode": _mode_prop(), "project": _string()})


def _confirm_schema(field: str) -> JsonDict:
    return _schema({"mode": _mode_prop("real"), field: _boolean(False)}, [field])


def _operation_schema(required: list[str] | None = None) -> JsonDict:
    return _schema({"mode": _mode_prop(), "project": _string(), "operation": _string(), "arguments": {"type": "object"}, "allow_apply": _boolean(False)}, required or ["operation"])


def _component_action_schema(required: list[str] | None = None) -> JsonDict:
    props = {
        "mode": _mode_prop(),
        "project": _string(),
        "allow_apply": _boolean(False),
        "component_name": _string(),
        "target_name": _string(),
        "target_component": _string(),
        "target_name": _string(),
        "file_id": _string(),
        "component_type": _string(),
        "group_name": _string(),
        "joint_name": _string(),
        "parent": _string(),
        "child": _string(),
        "sketch_name": _string(),
        "material": _string(),
        "appearance": _string(),
        "delta_mm": {"type": "array", "items": {"type": "number"}},
        "position_mm": {"type": "array", "items": {"type": "number"}},
        "axis": {"type": "string", "enum": ["x", "y", "z"]},
        "count": _integer(1, 200, 1),
        "spacing_mm": _number(),
        "metadata": {"type": "object"},
        "limits": {"type": "object"},
    }
    return _schema(props, required or [])


def _delete_schema() -> JsonDict:
    return _schema({"mode": _mode_prop(), "project": _string(), "allow_apply": _boolean(False), "allowed_names": {"type": "array", "items": {"type": "string"}}}, ["allowed_names"])


def _drawing_schema(required: list[str] | None = None) -> JsonDict:
    return _schema({"mode": _mode_prop(), "project": _string(), "target_name": _string(), "output_name": _string(), "include_bom": _boolean(True), "allow_apply": _boolean(False)}, required or [])


def _export_schema(extension: str) -> JsonDict:
    return _schema({"mode": _mode_prop(), "project": _string(), "target_name": _string(), "output_name": _string(), "format": {"type": "string", "enum": [extension], "default": extension}, "allow_apply": _boolean(False)})


def _string() -> JsonDict:
    return {"type": "string"}


def _boolean(default: bool | None = None) -> JsonDict:
    schema: JsonDict = {"type": "boolean"}
    if default is not None:
        schema["default"] = default
    return schema


def _integer(minimum: int | None = None, maximum: int | None = None, default: int | None = None) -> JsonDict:
    schema: JsonDict = {"type": "integer"}
    if minimum is not None:
        schema["minimum"] = minimum
    if maximum is not None:
        schema["maximum"] = maximum
    if default is not None:
        schema["default"] = default
    return schema


def _number() -> JsonDict:
    return {"type": "number"}


def _required(args: JsonDict, key: str) -> str:
    value = args.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{key} is required")
    return value


def _maybe_project(args: JsonDict) -> JsonDict:
    return {"project": args["project"]} if isinstance(args.get("project"), str) and args["project"].strip() else {}


def _safe_segment(value: str) -> str:
    if not value or any(part in value for part in ("/", "\\", "..")):
        raise ValueError("project must be a simple path segment")
    return value


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _component_records(state: JsonDict) -> list[JsonDict]:
    components = state.get("components", {})
    if isinstance(components, dict):
        return [
            _compact_record({"name": name, **(value if isinstance(value, dict) else {})}, _COMPONENT_FIELDS)
            for name, value in list(components.items())[:MAX_SNAPSHOT_RECORDS]
        ]
    if isinstance(components, list):
        return [_compact_record(value, _COMPONENT_FIELDS) for value in components[:MAX_SNAPSHOT_RECORDS] if isinstance(value, dict)]
    return []


def _body_records(state: JsonDict) -> list[JsonDict]:
    return _dict_records(state.get("bodies", {}), allowed_fields=_BODY_FIELDS)


def _occurrence_records(state: JsonDict) -> list[JsonDict]:
    return _dict_records(state.get("occurrences", {}), allowed_fields=_OCCURRENCE_FIELDS)


def _sketch_records(state: JsonDict) -> list[JsonDict]:
    return _dict_records(state.get("sketches", {}), allowed_fields=_SKETCH_FIELDS)


def _dict_records(value: Any, *, allowed_fields: set[str] | None = None) -> list[JsonDict]:
    if isinstance(value, dict):
        return [
            _compact_record({"name": name, **(item if isinstance(item, dict) else {"value": item})}, allowed_fields)
            for name, item in list(value.items())[:MAX_SNAPSHOT_RECORDS]
        ]
    if isinstance(value, list):
        return [_compact_record(item, allowed_fields) for item in value[:MAX_SNAPSHOT_RECORDS] if isinstance(item, dict)]
    return []


_COMPONENT_FIELDS = {
    "name",
    "bodies",
    "sketches",
    "features",
    "metadata",
    "part_number",
    "description",
    "material",
    "physical_material",
    "source_type",
    "visible",
    "parent",
    "path",
}
_BODY_FIELDS = {
    "name",
    "component",
    "bounding_box_mm",
    "bbox_mm",
    "bbox",
    "min_mm",
    "max_mm",
    "center_mm",
    "holes",
    "valid",
    "visible",
    "material",
    "appearance",
    "mass_kg",
    "volume_mm3",
    "area_mm2",
}
_OCCURRENCE_FIELDS = {
    "name",
    "component",
    "parent",
    "path",
    "index",
    "visible",
    "bounding_box_mm",
    "bbox_mm",
    "bbox",
    "min_mm",
    "max_mm",
    "center_mm",
}
_SKETCH_FIELDS = {
    "name",
    "component",
    "plane",
    "profiles_closed",
    "profiles",
    "is_fully_constrained",
    "constraint_count",
    "dimension_count",
}


def _compact_record(record: JsonDict, allowed_fields: set[str] | None) -> JsonDict:
    if allowed_fields is None:
        return _json_safe(record, depth=4, max_items=MAX_SNAPSHOT_LIST_ITEMS)
    compact: JsonDict = {}
    for key in allowed_fields:
        if key in record:
            compact[key] = _json_safe(record[key], depth=3, max_items=MAX_SNAPSHOT_LIST_ITEMS)
    if "name" not in compact and isinstance(record.get("name"), str):
        compact["name"] = record["name"]
    return compact


def _bbox(entity: JsonDict) -> list[float] | None:
    for key in ("bounding_box_mm", "bbox_mm", "bbox"):
        value = entity.get(key)
        if isinstance(value, list) and len(value) >= 3:
            return [float(item) for item in value[:3]]
    min_mm = entity.get("min_mm")
    max_mm = entity.get("max_mm")
    if isinstance(min_mm, list) and isinstance(max_mm, list) and len(min_mm) >= 3 and len(max_mm) >= 3:
        return [abs(float(max_mm[index]) - float(min_mm[index])) for index in range(3)]
    return None


def _center(entity: JsonDict) -> list[float] | None:
    value = entity.get("center_mm")
    if isinstance(value, list) and len(value) >= 3:
        return [float(item) for item in value[:3]]
    min_mm = entity.get("min_mm")
    max_mm = entity.get("max_mm")
    if isinstance(min_mm, list) and isinstance(max_mm, list) and len(min_mm) >= 3 and len(max_mm) >= 3:
        return [(float(min_mm[index]) + float(max_mm[index])) / 2 for index in range(3)]
    return None


def _distance(left: list[float], right: list[float]) -> float:
    return math.sqrt(sum((left[index] - right[index]) ** 2 for index in range(3)))


def _clearance(left_bbox: list[float] | None, right_bbox: list[float] | None) -> float | None:
    if not left_bbox or not right_bbox:
        return None
    return min(abs(float(left_bbox[index]) - float(right_bbox[index])) for index in range(3))


def _assembly_envelope(entities: list[JsonDict]) -> list[float]:
    boxes = [entity.get("bounding_box_mm") for entity in entities if entity.get("bounding_box_mm")]
    if not boxes:
        return [0.0, 0.0, 0.0]
    return [round(max(float(box[index]) for box in boxes), 4) for index in range(3)]


def _loose_components(components: list[JsonDict], occurrences: list[JsonDict]) -> list[JsonDict]:
    occurrence_components = {item.get("component") for item in occurrences}
    loose = []
    for component in components:
        if component.get("name") == "root":
            continue
        if not component.get("bodies") and not component.get("features") and component.get("name") not in occurrence_components:
            loose.append({"component": component.get("name"), "reason": "no bodies/features/occurrences"})
    return loose


def _unused_parts(components: list[JsonDict], bodies: list[JsonDict]) -> list[JsonDict]:
    records = []
    for item in [*components, *bodies]:
        name = str(item.get("name", ""))
        if re.search(r"(old|unused|legacy|backup|copy|tmp|delete)", name, re.IGNORECASE):
            records.append({"name": name, "reason": "name suggests old or unused part"})
    return records


def _alignment_issues(spatial: JsonDict) -> list[JsonDict]:
    issues = []
    for entity in spatial.get("entities", []):
        center = entity.get("center_mm")
        if center and any(abs(value) > 100000 for value in center):
            issues.append({"name": entity["name"], "reason": "entity center is far from origin", "center_mm": center})
    return issues


def _interference_findings(state: JsonDict) -> list[JsonDict]:
    interference = state.get("interference") or {}
    if isinstance(interference, dict):
        pairs = interference.get("pairs") or []
        return pairs if isinstance(pairs, list) else []
    return []


def _sketch_issues(sketches: list[JsonDict]) -> list[JsonDict]:
    issues = []
    for sketch in sketches:
        if sketch.get("profiles_closed") is False:
            issues.append({"sketch": sketch.get("name"), "reason": "open profile"})
        if not sketch.get("profiles"):
            issues.append({"sketch": sketch.get("name"), "reason": "no profiles"})
        if sketch.get("is_fully_constrained") is False:
            issues.append({"sketch": sketch.get("name"), "reason": "under constrained"})
    return issues


def _recommendations(findings: JsonDict) -> list[str]:
    recommendations = []
    if findings["root_bodies"]:
        recommendations.append("Move root-level bodies into named components before assembly work.")
    if findings["loose_components"]:
        recommendations.append("Review loose or empty components and either populate or remove them.")
    if findings["unused_parts"]:
        recommendations.append("Use controlled delete for legacy/unused parts after preview.")
    if findings["sketch_issues"]:
        recommendations.append("Repair open or under-constrained sketches before drawing/export.")
    if findings["interferences"]:
        recommendations.append("Resolve interferences before release or motion checks.")
    return recommendations or ["No blocking structural issues detected in the current snapshot."]


def _compact_mapping(value: Any) -> JsonDict:
    if not isinstance(value, dict):
        return {}
    compact: JsonDict = {}
    for key, item in list(value.items())[:MAX_SNAPSHOT_MAP_ITEMS]:
        compact[str(key)] = _json_safe(item, depth=4, max_items=MAX_SNAPSHOT_LIST_ITEMS)
    if len(value) > MAX_SNAPSHOT_MAP_ITEMS:
        compact["__truncated__"] = {"total_items": len(value), "included_items": MAX_SNAPSHOT_MAP_ITEMS}
    return compact


def _json_safe(value: Any, *, depth: int, max_items: int) -> Any:
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, str):
        return value if len(value) <= MAX_STRING_CHARS else value[:MAX_STRING_CHARS] + "...<truncated>"
    if isinstance(value, Path):
        return str(value)
    if depth <= 0:
        return _json_summary(value)
    if isinstance(value, dict):
        safe: JsonDict = {}
        for key, item in list(value.items())[:max_items]:
            safe[str(key)] = _json_safe(item, depth=depth - 1, max_items=max_items)
        if len(value) > max_items:
            safe["__truncated__"] = {"total_items": len(value), "included_items": max_items}
        return safe
    if isinstance(value, (list, tuple, set)):
        items = list(value)
        safe_items = [_json_safe(item, depth=depth - 1, max_items=max_items) for item in items[:max_items]]
        if len(items) > max_items:
            safe_items.append({"__truncated__": {"total_items": len(items), "included_items": max_items}})
        return safe_items
    return str(value)[:MAX_STRING_CHARS]


def _json_summary(value: Any) -> JsonDict | str:
    if isinstance(value, dict):
        return {"type": "object", "total_items": len(value)}
    if isinstance(value, (list, tuple, set)):
        return {"type": "array", "total_items": len(value)}
    text = str(value)
    return text if len(text) <= MAX_STRING_CHARS else text[:MAX_STRING_CHARS] + "...<truncated>"


def _mass_for_component(snapshot: JsonDict, component: str) -> float | None:
    props = snapshot.get("physical_properties", {}).get(component)
    if isinstance(props, dict):
        value = props.get("mass_kg") or props.get("mass")
        if isinstance(value, (int, float)):
            return round(float(value), 6)
    return None


def _mock_native_read(payload: JsonDict) -> JsonDict:
    query_type = payload.get("queryType")
    if query_type == "projects":
        return {"projects": [{"name": "Mock Project", "id": "mock.project"}]}
    if query_type == "document":
        operation = payload.get("operation")
        if operation == "search":
            return {"results": [{"name": payload.get("name", "mock_document"), "id": "mock.file"}]}
        if operation == "open":
            return {"results": [{"name": "Mock Active Document", "id": "mock.active", "isActive": True, "isModified": False}]}
        if operation == "recent":
            return {"results": [{"name": "Mock Recent Document", "id": "mock.recent"}]}
    if query_type == "apiDocumentation":
        return {"classes": [], "members": [{"name": payload.get("searchPattern"), "doc": "mock API documentation"}]}
    return {"result": {}}


def _mock_assets(asset_type: str) -> list[JsonDict]:
    if asset_type == "materials":
        return [{"name": "Aluminum 6061"}, {"name": "Steel"}, {"name": "ABS Plastic"}]
    return [{"name": "Polished Steel"}, {"name": "Matte Black"}, {"name": "Clear Anodized Aluminum"}]


def _asset_listing_script(asset_type: str) -> str:
    collection = "materials" if asset_type == "materials" else "appearances"
    return f"""import adsk.core, json

def run(_context: str):
    app = adsk.core.Application.get()
    names = []
    for library_index in range(app.materialLibraries.count):
        library = app.materialLibraries.item(library_index)
        if not library:
            continue
        items = getattr(library, "{collection}", None)
        if not items:
            continue
        for item_index in range(items.count):
            item = items.item(item_index)
            if item:
                names.append({{"name": item.name, "library": library.name}})
    print(json.dumps({{"{asset_type}": names[:500]}}, sort_keys=True))
"""


def _move_component_script(args: JsonDict) -> str:
    name = args.get("component_name") or args.get("target_name") or ""
    delta = args.get("delta_mm") or args.get("position_mm") or [0, 0, 0]
    payload = {"name": name, "delta_cm": [float(delta[index]) / 10 if index < len(delta) else 0 for index in range(3)]}
    return _script_with_payload(
        payload,
        """
import adsk.core, adsk.fusion
app = adsk.core.Application.get()
design = adsk.fusion.Design.cast(app.activeProduct)
root = design.rootComponent
target = None
for index in range(root.allOccurrences.count):
    occ = root.allOccurrences.item(index)
    if occ and (occ.name == PAYLOAD["name"] or (occ.component and occ.component.name == PAYLOAD["name"])):
        target = occ
        break
if not target:
    raise RuntimeError("component occurrence not found: " + PAYLOAD["name"])
transform = target.transform
translation = adsk.core.Vector3D.create(*PAYLOAD["delta_cm"])
transform.translation = transform.translation.copy()
transform.translation.add(translation)
target.transform = transform
print(json.dumps({"success": True, "moved": PAYLOAD["name"], "delta_cm": PAYLOAD["delta_cm"]}, sort_keys=True))
""",
    )


def _metadata_script(args: JsonDict) -> str:
    payload = {
        "target": args.get("target_name") or args.get("component_name") or "",
        "material": args.get("material"),
        "appearance": args.get("appearance"),
        "metadata": args.get("metadata") or {},
    }
    return _script_with_payload(
        payload,
        """
import adsk.core, adsk.fusion
app = adsk.core.Application.get()
design = adsk.fusion.Design.cast(app.activeProduct)
component = None
for index in range(design.allComponents.count):
    candidate = design.allComponents.item(index)
    if candidate and candidate.name == PAYLOAD["target"]:
        component = candidate
        break
if not component:
    raise RuntimeError("component not found: " + PAYLOAD["target"])
for key, value in (PAYLOAD.get("metadata") or {}).items():
    component.attributes.add("fusion_agent_metadata", str(key), json.dumps(value) if isinstance(value, (dict, list)) else str(value))
print(json.dumps({"success": True, "target": component.name, "metadata": PAYLOAD.get("metadata") or {}}, sort_keys=True))
""",
    )


def _joint_contract_script(args: JsonDict) -> str:
    payload = {"joint_name": args.get("joint_name") or args.get("group_name") or "fusion_agent_joint", "args": args}
    return _script_with_payload(
        payload,
        """
import adsk.core, adsk.fusion
app = adsk.core.Application.get()
design = adsk.fusion.Design.cast(app.activeProduct)
design.rootComponent.attributes.add("fusion_agent_joint_contracts", PAYLOAD["joint_name"], json.dumps(PAYLOAD["args"], sort_keys=True))
print(json.dumps({"success": True, "joint_contract": PAYLOAD["joint_name"]}, sort_keys=True))
""",
    )


def _placeholder_component_script(args: JsonDict) -> str:
    name = args.get("component_name") or args.get("component_type") or args.get("target_component") or "fusion_agent_component"
    payload = {"name": _safe_component_name(str(name)), "metadata": args}
    return _script_with_payload(
        payload,
        """
import adsk.core, adsk.fusion
app = adsk.core.Application.get()
design = adsk.fusion.Design.cast(app.activeProduct)
root = design.rootComponent
occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
occ.component.name = PAYLOAD["name"]
occ.component.attributes.add("fusion_agent_generated_component", "metadata", json.dumps(PAYLOAD["metadata"], sort_keys=True))
print(json.dumps({"success": True, "component": occ.component.name}, sort_keys=True))
""",
    )


def _attribute_marker_script(operation: str, args: JsonDict) -> str:
    payload = {"operation": operation, "args": args}
    return _script_with_payload(
        payload,
        """
import adsk.core, adsk.fusion
app = adsk.core.Application.get()
design = adsk.fusion.Design.cast(app.activeProduct)
design.rootComponent.attributes.add("fusion_agent_controlled_operations", PAYLOAD["operation"], json.dumps(PAYLOAD["args"], sort_keys=True))
print(json.dumps({"success": True, "operation": PAYLOAD["operation"], "recorded": True}, sort_keys=True))
""",
    )


def _script_with_payload(payload: JsonDict, body: str) -> str:
    return f"""import json
PAYLOAD = {json.dumps(payload, sort_keys=True)}
{body}
"""


def _safe_component_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_]+", "_", value).strip("_")
    return value or "fusion_agent_component"


def _simple_filename(value: str, extension: str) -> str:
    name = Path(value).name
    if not name.lower().endswith(f".{extension}"):
        name = f"{name}.{extension}"
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
    if len(name) > 96:
        suffix = f".{extension}"
        name = name[: 96 - len(suffix)].rstrip("._-") + suffix
    return name


def _safe_artifact_slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("._-")
    return (slug or "project")[:64]


def _action_arguments(args: JsonDict) -> JsonDict:
    return {key: value for key, value in args.items() if key not in {"mode", "project", "allow_apply", "operation"}}


def _affected_components(args: JsonDict) -> list[str]:
    return [
        str(value)
        for key, value in args.items()
        if key in {"component_name", "target_name", "target_component", "parent", "child"} and isinstance(value, str) and value
    ]


def _load_optional_json(path: Any) -> JsonDict | None:
    if not isinstance(path, str) or not path:
        return None
    candidate = Path(path)
    if not candidate.exists():
        return None
    return json.loads(candidate.read_text(encoding="utf-8"))


def _looks_dangerous_script(script: str) -> bool:
    blocked = ["os.remove", "shutil.rmtree", "subprocess", "socket", "requests.", "urllib.request"]
    return any(token in script for token in blocked)
