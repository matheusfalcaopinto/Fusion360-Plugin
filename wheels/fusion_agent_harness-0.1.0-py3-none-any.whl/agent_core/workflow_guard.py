"""Workflow checks that keep real Fusion writes deliberate and auditable."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


JsonDict = dict[str, Any]


def validate_real_run_preconditions(
    *,
    workspace_root: Path | str,
    project: str,
    prompt: str,
    dry_run_session_id: str | None,
    allow_existing_document_write: bool,
) -> JsonDict:
    """Require a matching passed dry-run before writing to a real document."""

    if not dry_run_session_id:
        raise ValueError(
            "real run_session requires dry_run_session_id from a successful "
            "fusion_agent_dry_run_session for the same prompt"
        )
    if not allow_existing_document_write:
        raise ValueError("real run_session requires allow_existing_document_write=true")
    _safe_segment(project, "project")
    _safe_segment(dry_run_session_id, "dry_run_session_id")

    session_dir = Path(workspace_root) / "projects" / project / "sessions" / dry_run_session_id
    journal_path = session_dir / "session_journal.json"
    spec_path = session_dir / "cad_spec.json"
    if not journal_path.exists():
        raise FileNotFoundError(f"dry-run journal not found: {journal_path}")
    if not spec_path.exists():
        raise FileNotFoundError(f"dry-run cad_spec.json not found: {spec_path}")

    journal = json.loads(journal_path.read_text(encoding="utf-8"))
    if journal.get("dry_run") is not True:
        raise ValueError("dry_run_session_id must reference a dry-run session")
    if journal.get("final_status") != "simulated":
        raise ValueError("dry-run session must have final_status='simulated'")
    verification = journal.get("verification_results") or {}
    if verification.get("passed") is not True:
        raise ValueError("dry-run verification must pass before a real run")
    if journal.get("user_prompt") != prompt:
        raise ValueError("dry-run prompt does not match requested real run prompt")

    return {
        "policy": "real_write_requires_matching_passed_dry_run",
        "dry_run_session_id": dry_run_session_id,
        "dry_run_journal_path": str(journal_path),
        "cad_spec_hash": _cad_spec_hash(spec_path),
    }


def _cad_spec_hash(path: Path) -> str:
    raw = path.read_text(encoding="utf-8")
    try:
        normalized = json.dumps(json.loads(raw), sort_keys=True, separators=(",", ":")).encode("utf-8")
    except json.JSONDecodeError:
        normalized = raw.encode("utf-8")
    return hashlib.sha256(normalized).hexdigest()


def _safe_segment(value: str, label: str) -> None:
    if not value or any(part in value for part in ("/", "\\", "..")):
        raise ValueError(f"{label} must be a simple path segment")
