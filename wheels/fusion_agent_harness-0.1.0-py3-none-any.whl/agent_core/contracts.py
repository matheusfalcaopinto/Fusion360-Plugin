"""Stable response contracts for agent-facing Fusion Agent tools."""

from __future__ import annotations

from pathlib import Path
from typing import Any


SCHEMA_VERSION = "1.1"

JsonDict = dict[str, Any]


def envelope_payload(tool_name: str, payload: JsonDict) -> JsonDict:
    """Return a tool payload with stable agent-readable metadata."""

    normalized = _jsonable(payload)
    if not isinstance(normalized, dict):
        normalized = {"result": normalized}
    envelope: JsonDict = {
        "schema_version": SCHEMA_VERSION,
        "tool": tool_name,
        "ok": normalized.get("ok", True),
        **normalized,
    }
    envelope["artifacts"] = artifact_refs_from_payload(normalized)
    return envelope


def error_payload(tool_name: str, exc: BaseException) -> JsonDict:
    """Return a structured MCP error payload."""

    error_type = type(exc).__name__
    return {
        "schema_version": SCHEMA_VERSION,
        "tool": tool_name,
        "ok": False,
        "error": {
            "code": _error_code(error_type),
            "type": error_type,
            "message": str(exc),
        },
        "artifacts": [],
    }


def artifact_refs_from_payload(payload: Any) -> list[JsonDict]:
    """Find path-like artifact references in a JSON-style payload."""

    refs: list[JsonDict] = []
    seen: set[tuple[str, str]] = set()

    def visit(value: Any, key: str | None = None) -> None:
        if isinstance(value, dict):
            for child_key, child_value in value.items():
                visit(child_value, str(child_key))
            return
        if isinstance(value, list):
            for child in value:
                visit(child, key)
            return
        if isinstance(value, Path):
            visit(str(value), key)
            return
        if not isinstance(value, str) or key is None:
            return
        normalized_key = key.lower()
        if not (
            normalized_key == "path"
            or normalized_key.endswith("_path")
            or normalized_key.endswith("_dir")
            or normalized_key.endswith("_root")
        ):
            return
        artifact_kind = "directory" if normalized_key.endswith(("_dir", "_root")) else "file"
        marker = (artifact_kind, value)
        if marker in seen:
            return
        seen.add(marker)
        refs.append({"kind": artifact_kind, "path": value, "field": key})

    visit(payload)
    return refs


def _jsonable(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {key: _jsonable(child) for key, child in value.items()}
    if isinstance(value, list | tuple):
        return [_jsonable(child) for child in value]
    return value


def _error_code(error_type: str) -> str:
    code = []
    for index, char in enumerate(error_type):
        if char.isupper() and index:
            code.append("_")
        code.append(char.lower())
    return "".join(code)
