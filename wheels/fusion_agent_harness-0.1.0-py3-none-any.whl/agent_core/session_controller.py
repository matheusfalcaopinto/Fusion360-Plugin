"""End-to-end session orchestration."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, Field

from agent_core.executor import ExecutionContext, ExecutionResult, Executor
from agent_core.planner import PlanningRequest, RuleBasedPlanner
from agent_core.repair_loop import RepairLoop
from fusion_mcp_adapter.adapter import FusionMcpAdapter
from fusion_mcp_adapter.manifest_store import ManifestStore
from fusion_mcp_adapter.mock_client import MOCK_NATIVE_TOOLS, MockMcpClient
from fusion_mcp_adapter.policy import ToolPolicy
from fusion_mcp_adapter.real_client import RealMcpClient
from fusion_tool_facade.facade import FusionFacade
from fusion_tool_facade.policy import MOCK_FACADE_NATIVE_MAP
from fusion_tool_facade.vendor_facade import VENDOR_FACADE_NATIVE_TOOLS, VendorFusionFacade, is_vendor_manifest
from memory.gate import MemoryGate
from memory.retriever import MemoryRetriever
from memory.store import MemoryStore
from memory.writer import MemoryWriter
from skills.loader import SkillLoader
from skills.router import SkillRouter
from telemetry.journal import SessionJournal
from telemetry.trace import JsonlTraceLogger
from verifier.geometry import GeometryVerifier
from verifier.result_models import VerificationResult


class SessionOptions(BaseModel):
    """Session configuration."""

    mode: str = "mock"
    project: str = "default"
    max_repairs: int = 5
    workspace_root: Path = Path("workspace")
    output_dir: Path = Path("outputs")
    manifest_dir: Path = Path("manifests")
    dry_run: bool = False

    model_config = {"arbitrary_types_allowed": True}


class SessionResult(BaseModel):
    """End-to-end session result."""

    session_id: str
    status: str
    cad_spec_path: Path
    journal_path: Path
    trace_path: Path
    execution: ExecutionResult
    verification: VerificationResult
    repair_attempts: list = Field(default_factory=list)
    memory_updates: list[str] = Field(default_factory=list)
    dry_run: bool = False

    model_config = {"arbitrary_types_allowed": True}


class VerifyActiveResult(BaseModel):
    """Verifier-only active design result."""

    session_id: str
    status: str
    cad_spec_path: Path
    journal_path: Path
    trace_path: Path
    verification: VerificationResult

    model_config = {"arbitrary_types_allowed": True}


class CaptureViewportResult(BaseModel):
    """Safe viewport capture result."""

    session_id: str
    status: str
    path: Path
    journal_path: Path
    trace_path: Path
    capture: dict

    model_config = {"arbitrary_types_allowed": True}


class SessionController:
    """Coordinate memory retrieval, planning, execution, verification, and journaling."""

    def __init__(self, planner: RuleBasedPlanner | None = None) -> None:
        self.planner = planner or RuleBasedPlanner()

    async def run(
        self,
        user_prompt: str,
        project: str | None = None,
        mode: str = "mock",
        options: SessionOptions | None = None,
    ) -> SessionResult:
        """Run one complete modeling session."""

        options = options or SessionOptions(mode=mode, project=project or "default")
        options.mode = mode
        options.project = project or options.project
        session_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        workspace_root = options.workspace_root
        output_dir = options.output_dir
        manifest_dir = options.manifest_dir

        memory_store = MemoryStore(workspace_root=workspace_root)
        memory_store.seed_global()
        retriever = MemoryRetriever(memory_store)
        retrieved = retriever.retrieve(user_prompt, project=options.project)
        gated_memory = MemoryGate().filter(retrieved, user_prompt)

        skills = SkillRouter(SkillLoader().load()).rank(user_prompt)
        spec = await self.planner.plan(
            PlanningRequest(
                user_prompt=user_prompt,
                project=options.project,
                memory=gated_memory,
                skills=[skill.name for skill in skills],
            )
        )

        journal = SessionJournal(workspace_root, options.project, session_id)
        trace_logger = JsonlTraceLogger(journal.trace_path)
        execution_context = ExecutionContext(mode=mode, project=options.project, output_dir=output_dir, dry_run=options.dry_run)

        if options.dry_run:
            trace_logger.log(
                {
                    "session_id": session_id,
                    "event": "dry_run_skipped_execution",
                    "mode": mode,
                    "project": options.project,
                }
            )
            executor = Executor()
            execution = await executor.execute(spec, execution_context)
            verification = _simulated_verification(spec)
            repair_loop: RepairLoop | None = None
            status = "simulated"
        else:
            facade = await self._build_facade(
                mode,
                options=options,
                trace_logger=trace_logger,
                session_id=session_id,
            )
            executor = Executor(facade)
            verifier = GeometryVerifier(facade)
            repair_loop = RepairLoop(
                verifier,
                max_total_attempts=options.max_repairs,
                executor=executor,
                trace_logger=trace_logger,
                session_id=session_id,
            )
            execution = await executor.execute(spec, execution_context)
            verification = await repair_loop.run(spec, context=execution_context)
            status = "success" if verification.passed else "failed"

        cad_spec_path = journal.write_text("cad_spec.json", spec.to_json_text())
        journal.write_text("prompt.md", user_prompt)

        memory_updates = MemoryWriter(memory_store).write_session_memory(
            project=options.project,
            session_id=session_id,
            prompt=user_prompt,
            verification=verification,
        )
        journal.write_json("verification.json", verification)
        journal_path = journal.finalize(
            mode=mode,
            user_prompt=user_prompt,
            cad_spec_path=cad_spec_path,
            verification=verification,
            final_status=status,
            summary=(
                f"Session {status}. "
                f"{'No MCP calls executed (dry-run). ' if options.dry_run else ''}"
                f"Created {len(execution.created_objects)} objects."
            ),
            memory_updates=memory_updates,
            exports=execution.exports,
            simulated=options.dry_run,
            repair_attempts=repair_loop.attempts if repair_loop else [],
            repaired=any(attempt.success for attempt in (repair_loop.attempts if repair_loop else [])),
        )

        return SessionResult(
            session_id=session_id,
            status=status,
            cad_spec_path=cad_spec_path,
            journal_path=journal_path,
            trace_path=journal.trace_path,
            execution=execution,
            verification=verification,
            repair_attempts=repair_loop.attempts if repair_loop else [],
            memory_updates=memory_updates,
            dry_run=options.dry_run,
        )

    async def inspect(self, mode: str = "mock", options: SessionOptions | None = None) -> dict:
        """Inspect a design through the configured facade."""

        options = options or SessionOptions(mode=mode)
        session_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        trace_logger = JsonlTraceLogger(Path("logs") / f"inspect_{session_id}.jsonl")
        facade = await self._build_facade(mode, options=options, trace_logger=trace_logger, session_id=session_id)
        return await facade.inspect_design()

    async def verify_active(
        self,
        user_prompt: str,
        project: str | None = None,
        mode: str = "mock",
        options: SessionOptions | None = None,
    ) -> VerifyActiveResult:
        """Plan a CadSpec for the prompt and verify it against the active design without executing geometry."""

        options = options or SessionOptions(mode=mode, project=project or "default")
        options.mode = mode
        options.project = project or options.project
        session_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")

        memory_store = MemoryStore(workspace_root=options.workspace_root)
        memory_store.seed_global()
        retrieved = MemoryRetriever(memory_store).retrieve(user_prompt, project=options.project)
        gated_memory = MemoryGate().filter(retrieved, user_prompt)
        skills = SkillRouter(SkillLoader().load()).rank(user_prompt)
        spec = await self.planner.plan(
            PlanningRequest(
                user_prompt=user_prompt,
                project=options.project,
                memory=gated_memory,
                skills=[skill.name for skill in skills],
            )
        )

        journal = SessionJournal(options.workspace_root, options.project, session_id)
        trace_logger = JsonlTraceLogger(journal.trace_path)
        facade = await self._build_facade(mode, options=options, trace_logger=trace_logger, session_id=session_id)
        verification = await GeometryVerifier(facade).verify(spec)
        status = "success" if verification.passed else "failed"

        cad_spec_path = journal.write_text("cad_spec.json", spec.to_json_text())
        journal.write_text("prompt.md", user_prompt)
        journal.write_json("verification.json", verification)
        journal_path = journal.finalize(
            mode=mode,
            user_prompt=user_prompt,
            cad_spec_path=cad_spec_path,
            verification=verification,
            final_status=status,
            summary=f"Verifier-only session {status}. No geometry execution was performed.",
            exports=[],
            simulated=False,
        )
        return VerifyActiveResult(
            session_id=session_id,
            status=status,
            cad_spec_path=cad_spec_path,
            journal_path=journal_path,
            trace_path=journal.trace_path,
            verification=verification,
        )

    async def capture_viewport(
        self,
        *,
        project: str | None = None,
        mode: str = "mock",
        options: SessionOptions | None = None,
        output_dir: Path | str | None = None,
        name: str = "active_design_capture",
        view: str = "isometric",
        isolate_prefix: str | None = None,
        width: int = 1600,
        height: int = 1100,
    ) -> CaptureViewportResult:
        """Capture the active Fusion viewport through the safe facade."""

        options = options or SessionOptions(mode=mode, project=project or "default")
        options.mode = mode
        options.project = project or options.project
        if output_dir is not None:
            options.output_dir = Path(output_dir)
        options.output_dir.mkdir(parents=True, exist_ok=True)
        session_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        journal = SessionJournal(options.workspace_root, options.project, session_id)
        trace_logger = JsonlTraceLogger(journal.trace_path)
        facade = await self._build_facade(mode, options=options, trace_logger=trace_logger, session_id=session_id)

        filename = name if name.lower().endswith(".png") else f"{name}.png"
        path = options.output_dir / filename
        capture_payload = await facade.capture_viewport(
            name=Path(filename).stem,
            path=path,
            view=view,
            isolate_prefix=isolate_prefix,
            width=width,
            height=height,
        )
        status = "success"
        verification = VerificationResult.pass_result(metrics={"capture": capture_payload.get("screenshot", capture_payload)})
        cad_spec_path = journal.write_text("cad_spec.json", "{}\n")
        journal.write_text("prompt.md", f"capture {view} viewport")
        journal.write_json("verification.json", verification)
        journal.write_json("capture.json", capture_payload)
        journal_path = journal.finalize(
            mode=mode,
            user_prompt=f"capture {view} viewport",
            cad_spec_path=cad_spec_path,
            verification=verification,
            final_status=status,
            summary=f"Viewport capture {status}: {path}",
            exports=[str(path)],
            simulated=False,
        )
        return CaptureViewportResult(
            session_id=session_id,
            status=status,
            path=path,
            journal_path=journal_path,
            trace_path=journal.trace_path,
            capture=capture_payload,
        )

    async def discover_tools(self, mode: str = "real", options: SessionOptions | None = None):
        """Discover and save native MCP tools."""

        options = options or SessionOptions(mode=mode)
        client = MockMcpClient() if mode == "mock" else RealMcpClient()
        adapter = FusionMcpAdapter(
            client=client,
            manifest_store=ManifestStore(options.manifest_dir),
            policy=ToolPolicy.from_manifest(MOCK_NATIVE_TOOLS if mode == "mock" else set()),
        )
        return await adapter.discover(save=True)

    async def _build_facade(
        self,
        mode: str,
        options: SessionOptions,
        trace_logger: JsonlTraceLogger,
        session_id: str,
    ) -> FusionFacade:
        if mode == "mock":
            client = MockMcpClient()
            policy = ToolPolicy.from_manifest(MOCK_NATIVE_TOOLS)
            manifest_store = ManifestStore(options.manifest_dir)
            return FusionFacade(
                FusionMcpAdapter(
                    client=client,
                    manifest_store=manifest_store,
                    policy=policy,
                    trace_logger=trace_logger,
                    session_id=session_id,
                )
            )

        manifest_store = ManifestStore(options.manifest_dir)
        manifest = manifest_store.load_latest()
        if manifest is None:
            raise RuntimeError(
                "No discovered real MCP manifest. Run `tools discover --real` before executing real sessions."
            )

        client = RealMcpClient()
        manifest_names = manifest.names()
        if is_vendor_manifest(manifest_names):
            policy = ToolPolicy.from_manifest(VENDOR_FACADE_NATIVE_TOOLS & manifest_names)
            return VendorFusionFacade(
                FusionMcpAdapter(
                    client=client,
                    manifest=manifest,
                    manifest_store=manifest_store,
                    policy=policy,
                    trace_logger=trace_logger,
                    session_id=session_id,
                ),
                available_tools=manifest_names,
            )

        policy = ToolPolicy.from_manifest(set(MOCK_FACADE_NATIVE_MAP.values()) & manifest_names)
        return FusionFacade(
            FusionMcpAdapter(
                client=client,
                manifest=manifest,
                manifest_store=manifest_store,
                policy=policy,
                trace_logger=trace_logger,
                session_id=session_id,
            )
        )


def _simulated_verification(spec) -> VerificationResult:
    """Return a deterministic pass result for dry-run sessions."""

    return VerificationResult(
        passed=True,
        metrics={
            "simulated": True,
            "planned_components": len(spec.components),
            "planned_features": sum(len(component.features) for component in spec.components),
            "planned_parameters": len(spec.parameters),
            "planned_exports": [
                feature.name
                for component in spec.components
                for feature in component.features
                if feature.type == "export"
            ],
        },
    )
