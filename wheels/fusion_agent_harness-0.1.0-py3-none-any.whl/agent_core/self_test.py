"""Built-in safe self-test suite for the Fusion Agent harness."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable

from agent_core.executor import ExecutionContext, Executor
from agent_core.planner import PlanningRequest, RuleBasedPlanner
from agent_core.session_controller import SessionController, SessionOptions
from benchmark.loader import load_benchmark_cases
from benchmark.runner import BenchmarkRunner
from cad_spec.models import CadSpec
from fusion_mcp_adapter.manifest_store import ManifestStore
from fusion_mcp_adapter.real_client import RealMcpClient
from skills.loader import SkillLoader
from skills.router import SkillRouter
from telemetry.journal import SessionJournal
from telemetry.trace import JsonlTraceLogger
from verifier.geometry import GeometryVerifier
from verifier.result_models import FailureCode, VerificationIssue, VerificationResult


JsonDict = dict[str, Any]
Check = Callable[[], Awaitable[JsonDict]]


async def run_self_test(
    *,
    project: str = "self_test",
    workspace_root: Path | str = Path("workspace"),
    output_dir: Path | str = Path("outputs"),
    manifest_dir: Path | str = Path("manifests"),
    include_real_readonly: bool = False,
    include_real_write_sandbox: bool = False,
    include_real_capture_sandbox: bool = False,
    run_benchmark: bool = True,
) -> JsonDict:
    """Run a safe harness smoke suite and return JSON diagnostics."""

    workspace = Path(workspace_root)
    outputs = Path(output_dir)
    manifests = Path(manifest_dir)
    controller = SessionController()
    checks: list[JsonDict] = []

    async def record(name: str, callback: Check) -> None:
        try:
            details = await callback()
            checks.append({"name": name, "ok": True, "details": details})
        except Exception as exc:  # noqa: BLE001 - diagnostic boundary reports every failure
            checks.append({"name": name, "ok": False, "error": f"{type(exc).__name__}: {exc}"})

    async def planner_check() -> JsonDict:
        spec = await RuleBasedPlanner().plan(
            PlanningRequest(user_prompt="Create a 40 x 20 x 5 mm plate.", project=project)
        )
        CadSpec.model_validate_json(spec.to_json_text())
        return {
            "parameters": [parameter.name for parameter in spec.parameters],
            "components": [component.name for component in spec.components],
        }

    async def read_only_guard_check() -> JsonDict:
        try:
            await RuleBasedPlanner().plan(
                PlanningRequest(
                    user_prompt="Read the active design and list all component bounding boxes. Do not create geometry.",
                    project=project,
                )
            )
        except ValueError as exc:
            return {"rejected": True, "error": str(exc)}
        raise AssertionError("read-only prompt unexpectedly produced a CadSpec")

    async def mock_inspect_check() -> JsonDict:
        inspection = await controller.inspect(mode="mock", options=_options(project, workspace, outputs, manifests))
        state = inspection.get("state", {})
        return {"units": state.get("units"), "body_count": len(state.get("bodies", {}))}

    async def mock_extract_check() -> JsonDict:
        result = await controller.extract_geometry(
            project=project,
            mode="mock",
            options=_options(project, workspace, outputs, manifests),
        )
        return {"status": result.status, "returned": result.counts["returned"], "artifact": str(result.extraction_path)}

    async def mock_dry_run_check() -> JsonDict:
        result = await controller.run(
            "Create a 40 x 20 x 5 mm plate.",
            project=project,
            mode="mock",
            options=_options(project, workspace, outputs, manifests, dry_run=True),
        )
        return {"status": result.status, "session_id": result.session_id, "passed": result.verification.passed}

    async def mock_run_check() -> JsonDict:
        result = await controller.run(
            "Create a 40 x 20 x 5 mm plate.",
            project=project,
            mode="mock",
            options=_options(project, workspace, outputs, manifests),
        )
        return {
            "status": result.status,
            "session_id": result.session_id,
            "passed": result.verification.passed,
            "body_count": result.verification.metrics.get("body_count"),
        }

    async def mock_capture_check() -> JsonDict:
        result = await controller.capture_viewport(
            project=project,
            mode="mock",
            options=_options(project, workspace, outputs, manifests),
            output_dir=outputs,
            name=f"{project}_capture",
            width=320,
            height=240,
        )
        data = Path(result.path).read_bytes()
        if data[:8] != b"\x89PNG\r\n\x1a\n":
            raise AssertionError("mock capture did not write a valid PNG signature")
        return {"status": result.status, "bytes": len(data), "path": str(result.path)}

    async def skills_check() -> JsonDict:
        registry = SkillLoader().load()
        skills = registry.all()
        ranked = SkillRouter(registry).rank("create a parametric Fusion plate", limit=3)
        if not skills:
            raise AssertionError("no harness skills loaded")
        if not ranked:
            raise AssertionError("skill router returned no skills")
        return {"skill_count": len(skills), "top_ranked": [skill.name for skill in ranked]}

    async def benchmark_check() -> JsonDict:
        suite = Path("benchmarks") / "v0_parametric_parts.md"
        case_count = len(load_benchmark_cases(suite))
        runner = BenchmarkRunner(workspace_root=workspace, output_dir=outputs, manifest_dir=manifests)
        results = await runner.run(suite, mode="mock", project=project, dry_run=False)
        failed = [result for result in results if result.status not in {"success", "simulated"}]
        if failed:
            raise AssertionError(f"{len(failed)} benchmark cases failed")
        return {"case_count": case_count, "result_count": len(results)}

    async def real_readonly_check() -> JsonDict:
        client = RealMcpClient(timeout_seconds=8)
        manifest = await client.list_tools()
        return {"endpoint": client.endpoint, "tool_count": len(manifest.tools), "tools": sorted(manifest.names())}

    async def real_write_sandbox_check() -> JsonDict:
        return await _run_real_write_sandbox_check(
            project=project,
            workspace_root=workspace,
            output_dir=outputs,
            manifest_dir=manifests,
            include_capture=include_real_capture_sandbox,
        )

    await record("planner_generates_valid_spec", planner_check)
    await record("read_only_prompt_rejected", read_only_guard_check)
    await record("mock_inspect", mock_inspect_check)
    await record("mock_extract_geometry", mock_extract_check)
    await record("mock_dry_run_session", mock_dry_run_check)
    await record("mock_run_session", mock_run_check)
    await record("mock_capture_viewport", mock_capture_check)
    await record("skills_load_and_rank", skills_check)
    if run_benchmark:
        await record("mock_benchmark_suite", benchmark_check)
    if include_real_readonly:
        await record("real_mcp_readonly_list_tools", real_readonly_check)
    if include_real_write_sandbox:
        await record("real_write_sandbox_session", real_write_sandbox_check)

    failed = [check for check in checks if not check["ok"]]
    return {
        "ok": not failed,
        "project": project,
        "workspace_root": str(workspace),
        "output_dir": str(outputs),
        "manifest_dir": str(manifests),
        "include_real_readonly": include_real_readonly,
        "include_real_write_sandbox": include_real_write_sandbox,
        "include_real_capture_sandbox": include_real_capture_sandbox,
        "run_benchmark": run_benchmark,
        "passed": len(checks) - len(failed),
        "failed": len(failed),
        "checks": checks,
    }


async def run_real_sandbox_session(
    *,
    project: str = "sandbox",
    prompt: str = "Create a 30 x 20 x 4 mm plate.",
    workspace_root: Path | str = Path("workspace"),
    output_dir: Path | str = Path("outputs"),
    manifest_dir: Path | str = Path("manifests"),
    include_capture: bool = True,
) -> JsonDict:
    """Run one real write in a disposable scratch document and close it unsaved."""

    workspace = Path(workspace_root)
    outputs = Path(output_dir)
    manifests = Path(manifest_dir)
    if ManifestStore(manifests).load_latest(source="fusion_real") is None:
        await SessionController().discover_tools(mode="real", options=SessionOptions(mode="real", manifest_dir=manifests))
    return await _run_real_write_sandbox_check(
        project=project,
        workspace_root=workspace,
        output_dir=outputs,
        manifest_dir=manifests,
        include_capture=include_capture,
        prompt=prompt,
    )


def _options(
    project: str,
    workspace_root: Path,
    output_dir: Path,
    manifest_dir: Path,
    *,
    dry_run: bool = False,
) -> SessionOptions:
    return SessionOptions(
        mode="mock",
        project=project,
        workspace_root=workspace_root,
        output_dir=output_dir,
        manifest_dir=manifest_dir,
        dry_run=dry_run,
    )


async def _run_real_write_sandbox_check(
    *,
    project: str,
    workspace_root: Path,
    output_dir: Path,
    manifest_dir: Path,
    include_capture: bool = False,
    prompt: str = "Create a 30 x 20 x 4 mm plate.",
) -> JsonDict:
    """Run one real write session in a disposable Fusion document."""

    session_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    scratch_name = f"fusion_agent_scratch_{session_id}"
    scratch_token = f"{project}_{session_id}"
    options = SessionOptions(
        mode="real",
        project=project,
        workspace_root=workspace_root,
        output_dir=output_dir,
        manifest_dir=manifest_dir,
    )
    journal = SessionJournal(workspace_root, project, session_id)
    trace_logger = JsonlTraceLogger(journal.trace_path)
    controller = SessionController()
    spec = await RuleBasedPlanner().plan(PlanningRequest(user_prompt=prompt, project=project))
    execution = None
    capture = None
    verification: VerificationResult | None = None
    scratch: dict[str, Any] = {"name": scratch_name, "token": scratch_token, "opened": None, "closed": None}
    failure_error: str | None = None

    cad_spec_path = journal.write_text("cad_spec.json", spec.to_json_text())
    journal.write_text("prompt.md", prompt)
    facade = await controller._build_facade("real", options=options, trace_logger=trace_logger, session_id=session_id)
    open_scratch = getattr(facade, "open_scratch_document", None)
    close_scratch = getattr(facade, "close_scratch_document", None)
    close_empty_unsaved = getattr(facade, "close_empty_unsaved_document", None)
    if not callable(open_scratch) or not callable(close_scratch):
        raise RuntimeError("active real facade does not support scratch document isolation")

    try:
        scratch["opened"] = await open_scratch(name=scratch_name, token=scratch_token)
        execution = await Executor(facade).execute(
            spec,
            ExecutionContext(mode="real", project=project, output_dir=output_dir, dry_run=False),
        )
        verification = await GeometryVerifier(facade).verify(spec)
        if include_capture:
            output_dir.mkdir(parents=True, exist_ok=True)
            capture_path = output_dir / f"{project}_{session_id}_real_sandbox.png"
            capture = await facade.capture_viewport(
                name=f"{project}_{session_id}_real_sandbox",
                path=capture_path,
                view="isometric",
                width=640,
                height=480,
            )
        if not verification.passed:
            failure_error = "real sandbox write verification failed"
    except Exception as exc:  # noqa: BLE001 - self-test must close scratch and journal diagnostics
        failure_error = f"{type(exc).__name__}: {exc}"
        verification = VerificationResult(
            passed=False,
            issues=[
                VerificationIssue(
                    code=FailureCode.UNKNOWN,
                    message="real sandbox write failed",
                    details={"error": failure_error, "scratch": scratch},
                )
            ],
            metrics={"real_write_sandbox": {"scratch": scratch, "error": failure_error}},
        )
    finally:
        if scratch.get("opened") is not None:
            try:
                scratch["closed"] = await close_scratch(token=scratch_token)
                if callable(close_empty_unsaved):
                    try:
                        scratch["empty_unsaved_cleanup"] = await close_empty_unsaved()
                    except Exception as exc:  # noqa: BLE001 - no-op when Fusion returns to a real document
                        scratch["empty_unsaved_cleanup"] = {
                            "skipped": True,
                            "reason": f"{type(exc).__name__}: {exc}",
                        }
            except Exception as exc:  # noqa: BLE001 - close failure is part of diagnostics
                scratch["close_error"] = f"{type(exc).__name__}: {exc}"
                failure_error = failure_error or scratch["close_error"]

    verification = verification or VerificationResult(
        passed=False,
        issues=[
            VerificationIssue(
                code=FailureCode.UNKNOWN,
                message="real sandbox write did not produce verification",
                details={"scratch": scratch},
            )
        ],
        metrics={"real_write_sandbox": {"scratch": scratch}},
    )
    journal.write_json("verification.json", verification)
    scratch_path = journal.write_json(
        "scratch_document.json",
        {
            "session_id": session_id,
            "scratch": scratch,
            "execution": execution,
            "capture": capture,
            "verification": verification,
        },
    )
    final_status = "success" if verification.passed and not failure_error and not scratch.get("close_error") else "failed"
    journal_path = journal.finalize(
        mode="real",
        user_prompt=prompt,
        cad_spec_path=cad_spec_path,
        verification=verification,
        final_status=final_status,
        summary=f"Real sandbox write self-test {final_status}.",
        exports=[],
        simulated=False,
    )
    if failure_error:
        raise RuntimeError(failure_error)
    if scratch.get("close_error"):
        raise RuntimeError(str(scratch["close_error"]))
    if not verification.passed:
        raise RuntimeError("real sandbox write verification failed")
    return {
        "status": final_status,
        "session_id": session_id,
        "journal_path": str(journal_path),
        "scratch_path": str(scratch_path),
        "scratch_closed": bool((scratch.get("closed") or {}).get("scratch_document", {}).get("closed_without_saving")),
        "body_count": verification.metrics.get("body_count"),
        "bounding_box_mm": verification.metrics.get("bounding_box_mm"),
        "capture": capture,
    }
